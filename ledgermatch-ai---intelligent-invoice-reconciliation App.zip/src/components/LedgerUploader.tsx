import React, { useRef, useState } from 'react';
import {
  FileSpreadsheet,
  UploadCloud,
  Download,
  Sparkles,
  ArrowRight,
  SlidersHorizontal,
  Trash2,
  FileCheck,
} from 'lucide-react';
import { LedgerRecord } from '../types/reconciliation';
import { generateSampleLedgerFile } from '../utils/excelParser';
import { formatINR } from '../utils/matchingEngine';

interface LedgerUploaderProps {
  ledgerRecords: LedgerRecord[];
  fileName?: string;
  detectedColumns?: {
    invoiceNumber: string;
    vendorName: string;
    vendorGstin?: string;
    date: string;
    taxableAmount?: string;
    cgst?: string;
    sgst?: string;
    igst?: string;
    amount: string;
    tax?: string;
    description?: string;
    accountCode?: string;
  };
  onUploadExcel: (file: File) => void;
  onLoadSampleLedger: () => void;
  onClearLedger: () => void;
  onProceedToReconciliation: () => void;
  hasInvoices: boolean;
}

export const LedgerUploader: React.FC<LedgerUploaderProps> = ({
  ledgerRecords,
  fileName,
  detectedColumns,
  onUploadExcel,
  onLoadSampleLedger,
  onClearLedger,
  onProceedToReconciliation,
  hasInvoices,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [showColumnMap, setShowColumnMap] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (
        file.name.endsWith('.xlsx') ||
        file.name.endsWith('.xls') ||
        file.name.endsWith('.csv')
      ) {
        onUploadExcel(file);
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUploadExcel(e.target.files[0]);
      e.target.value = '';
    }
  };

  const downloadSampleTemplate = () => {
    const blob = generateSampleLedgerFile();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Sample_GST_Purchase_Ledger.xlsx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const totalLedgerAmount = ledgerRecords.reduce((sum, r) => sum + r.amount, 0);
  const totalCgst = ledgerRecords.reduce((sum, r) => sum + r.cgst, 0);
  const totalSgst = ledgerRecords.reduce((sum, r) => sum + r.sgst, 0);
  const totalIgst = ledgerRecords.reduce((sum, r) => sum + r.igst, 0);

  return (
    <div className="space-y-6">
      {/* Step Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            2. Purchase Ledger Ingestion (Tally / Zoho / Excel)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Upload your accounts purchase register (.xlsx, .xls, .csv). Supports Tally ERP/Prime, Zoho Books, Marg, and ClearTax exports.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={downloadSampleTemplate}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-2xs"
            title="Download ready-to-test Indian GST Excel template"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Download GST Template (.xlsx)</span>
          </button>

          <button
            onClick={onLoadSampleLedger}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Load Indian Demo Ledger</span>
          </button>
        </div>
      </div>

      {/* Upload Dropzone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-xl p-7 text-center transition-all cursor-pointer ${
          isDragging
            ? 'border-emerald-600 bg-emerald-50/40 scale-[0.99]'
            : 'border-slate-300 hover:border-slate-400 bg-white'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          className="hidden"
          onChange={handleFileInputChange}
        />

        <div className="flex flex-col items-center justify-center space-y-2.5">
          <div className="w-11 h-11 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
            <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
          </div>

          <div>
            <p className="text-sm font-bold text-slate-900">
              {fileName ? (
                <span>Loaded ledger file: <span className="text-emerald-700 font-mono">{fileName}</span></span>
              ) : (
                <>
                  Drag & drop Excel ledger here, or <span className="text-indigo-600 hover:underline">choose file</span>
                </>
              )}
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Supports Excel (.xlsx, .xls) and standard CSV purchase ledgers with GST columns
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span className="flex items-center gap-1 font-medium text-emerald-800">
              <FileCheck className="w-3.5 h-3.5 text-emerald-600" /> Auto-Detects Indian GST Headers:
            </span>
            <span>Voucher/Inv #</span>
            <span>·</span>
            <span>Supplier & GSTIN</span>
            <span>·</span>
            <span>CGST</span>
            <span>·</span>
            <span>SGST</span>
            <span>·</span>
            <span>IGST</span>
            <span>·</span>
            <span>Bill Amount (₹)</span>
          </div>
        </div>
      </div>

      {/* Ledger Records Table */}
      {ledgerRecords.length > 0 && (
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-xs">
          {/* Header Bar */}
          <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 text-xs font-medium text-slate-700">
              <span className="font-bold text-slate-900">{ledgerRecords.length} Ledger Records</span>
              <span>·</span>
              <span className="font-mono tabular-nums text-slate-800">
                Total Ledger Amount: <span className="font-bold text-slate-900">{formatINR(totalLedgerAmount)}</span>
              </span>
              <span>·</span>
              <span className="text-slate-600 font-mono text-[11px]">
                CGST: {formatINR(totalCgst)} · SGST: {formatINR(totalSgst)} · IGST: {formatINR(totalIgst)}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {detectedColumns && (
                <button
                  onClick={() => setShowColumnMap(!showColumnMap)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded transition-colors"
                >
                  <SlidersHorizontal className="w-3 h-3 text-slate-500" />
                  <span>Column Headers</span>
                </button>
              )}

              <button
                onClick={onClearLedger}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-rose-600 hover:bg-rose-50 rounded transition-colors"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear</span>
              </button>
            </div>
          </div>

          {/* Column Mapping Details */}
          {showColumnMap && detectedColumns && (
            <div className="p-3 bg-slate-100/70 border-b border-slate-200 text-xs">
              <div className="font-bold text-slate-800 mb-2">Auto-Mapped Ledger Columns:</div>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 text-[11px]">
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Invoice #:</span>
                  <span className="font-mono font-medium text-slate-800">{detectedColumns.invoiceNumber}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Supplier:</span>
                  <span className="font-mono font-medium text-slate-800">{detectedColumns.vendorName}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">GSTIN:</span>
                  <span className="font-mono font-medium text-slate-800">{detectedColumns.vendorGstin || 'Not present'}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">CGST:</span>
                  <span className="font-mono font-medium text-slate-800">{detectedColumns.cgst || '—'}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">SGST:</span>
                  <span className="font-mono font-medium text-slate-800">{detectedColumns.sgst || '—'}</span>
                </div>
                <div className="bg-white p-1.5 rounded border border-slate-200">
                  <span className="text-slate-400 block text-[10px]">Total Amount:</span>
                  <span className="font-mono font-medium text-slate-800">{detectedColumns.amount}</span>
                </div>
              </div>
            </div>
          )}

          {/* Records Table */}
          <div className="overflow-x-auto max-h-[380px]">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-medium sticky top-0 z-10">
                <tr>
                  <th className="py-2.5 px-3 w-10 text-center">#</th>
                  <th className="py-2.5 px-3">Voucher / Bill #</th>
                  <th className="py-2.5 px-3">Supplier Name & GSTIN</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3 text-right">Taxable (₹)</th>
                  <th className="py-2.5 px-3 text-right">CGST (₹)</th>
                  <th className="py-2.5 px-3 text-right">SGST (₹)</th>
                  <th className="py-2.5 px-3 text-right">IGST (₹)</th>
                  <th className="py-2.5 px-3 text-right font-bold">Total Amount (₹)</th>
                  <th className="py-2.5 px-3">Narration / Account</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ledgerRecords.map((record) => (
                  <tr key={record.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2 px-3 text-center text-slate-400 font-mono text-[11px]">
                      {record.rowIndex}
                    </td>
                    <td className="py-2 px-3 font-mono font-semibold text-slate-900 whitespace-nowrap">
                      {record.invoiceNumber || '—'}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span className="font-medium text-slate-800 block">{record.vendorName}</span>
                      {record.vendorGstin && (
                        <span className="text-[10px] font-mono text-slate-500">{record.vendorGstin}</span>
                      )}
                    </td>
                    <td className="py-2 px-3 font-mono text-slate-600 whitespace-nowrap text-[11px]">
                      {record.date}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-700 whitespace-nowrap">
                      {formatINR(record.taxableAmount || 0)}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600 whitespace-nowrap">
                      {record.cgst > 0 ? formatINR(record.cgst) : '—'}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600 whitespace-nowrap">
                      {record.sgst > 0 ? formatINR(record.sgst) : '—'}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-600 whitespace-nowrap">
                      {record.igst > 0 ? formatINR(record.igst) : '—'}
                    </td>
                    <td className="py-2 px-3 text-right font-mono font-bold tabular-nums text-slate-900 whitespace-nowrap">
                      {formatINR(record.amount)}
                    </td>
                    <td className="py-2 px-3 text-slate-500 max-w-[200px] truncate" title={record.description || record.accountCode}>
                      {record.description || record.accountCode || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              {hasInvoices
                ? 'Both invoices and ledger records are ready. Proceed to run GST matching.'
                : 'Upload or load sample invoices in Step 1 to begin comparison.'}
            </span>

            <button
              onClick={onProceedToReconciliation}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer shadow-xs"
            >
              <span>Run GST Matching Engine</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
