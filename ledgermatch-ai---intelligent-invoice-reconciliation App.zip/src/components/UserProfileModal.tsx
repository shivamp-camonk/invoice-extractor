import React from 'react';
import { User } from 'firebase/auth';
import {
  User as UserIcon,
  X,
  Mail,
  ShieldCheck,
  Database,
  ExternalLink,
  Key,
  Calendar,
  LogOut,
  FolderOpen,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import firebaseConfig from '../../firebase-applet-config.json';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onSignIn: () => void;
  onSignOut: () => void;
  savedSessionsCount: number;
  invoicesCount: number;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSignIn,
  onSignOut,
  savedSessionsCount,
  invoicesCount,
}) => {
  if (!isOpen) return null;

  const projectId = firebaseConfig.projectId;
  const databaseId = firebaseConfig.firestoreDatabaseId;

  const firebaseAuthConsoleUrl = `https://console.firebase.google.com/project/${projectId}/authentication/users`;
  const firestoreConsoleUrl = `https://console.firebase.google.com/project/${projectId}/firestore/databases/${databaseId}/data`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <UserIcon className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">User Account & Login Details</h3>
              <p className="text-xs text-slate-500">Authenticated via Firebase Google Sign-In</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 space-y-4 text-xs">
          {currentUser ? (
            <>
              {/* User Avatar Card */}
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex items-center gap-3.5">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'User'}
                    className="w-12 h-12 rounded-full border-2 border-indigo-200 shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center text-base font-bold shrink-0">
                    {currentUser.displayName ? currentUser.displayName[0].toUpperCase() : 'U'}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900 truncate">
                      {currentUser.displayName || 'Authorized User'}
                    </span>
                    <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded font-semibold text-[10px]">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      <span>Verified</span>
                    </span>
                  </div>
                  <div className="text-slate-600 flex items-center gap-1.5 mt-0.5 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono text-slate-800">{currentUser.email}</span>
                  </div>
                </div>
              </div>

              {/* Login & Security Parameters */}
              <div className="space-y-2 border border-slate-200 rounded-lg p-3.5 bg-white">
                <div className="font-bold text-slate-900 pb-1.5 border-b border-slate-100 uppercase tracking-wider text-[10px] text-slate-500">
                  Login & Identity Parameters
                </div>

                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Mail className="w-3 h-3 text-slate-400" /> Email:
                  </span>
                  <span className="font-mono font-medium text-slate-900">{currentUser.email || '—'}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Key className="w-3 h-3 text-slate-400" /> Firebase Auth UID:
                  </span>
                  <span className="font-mono text-[11px] text-slate-700 bg-slate-100 px-1 rounded select-all" title={currentUser.uid}>
                    {currentUser.uid.slice(0, 14)}...
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <ShieldCheck className="w-3 h-3 text-slate-400" /> Auth Provider:
                  </span>
                  <span className="font-medium text-indigo-700">Google OAuth 2.0</span>
                </div>

                <div className="flex justify-between py-1">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Calendar className="w-3 h-3 text-slate-400" /> Session Started:
                  </span>
                  <span className="text-slate-700 font-mono">
                    {currentUser.metadata.lastSignInTime
                      ? new Date(currentUser.metadata.lastSignInTime).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'Current session'}
                  </span>
                </div>
              </div>

              {/* Cloud Database & Console Links */}
              <div className="space-y-2 border border-slate-200 rounded-lg p-3.5 bg-slate-50">
                <div className="font-bold text-slate-900 pb-1.5 border-b border-slate-200 uppercase tracking-wider text-[10px] text-slate-500 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Database className="w-3 h-3 text-indigo-600" /> Connected Firestore Database
                  </span>
                  <span className="text-emerald-700 font-semibold text-[10px]">Live & Active</span>
                </div>

                <div className="space-y-1 pt-1 text-[11px]">
                  <div className="flex justify-between text-slate-600">
                    <span>Database ID:</span>
                    <span className="font-mono text-slate-800 text-[10px] bg-white px-1.5 py-0.5 rounded border border-slate-200 select-all">
                      {databaseId}
                    </span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span>Cloud Region:</span>
                    <span className="font-mono text-slate-800">asia-southeast1</span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span>Saved Cloud Audits:</span>
                    <span className="font-bold text-slate-800">{savedSessionsCount} session(s)</span>
                  </div>

                  <div className="flex justify-between text-slate-600">
                    <span>Stored Invoices:</span>
                    <span className="font-bold text-slate-800">{invoicesCount} record(s)</span>
                  </div>
                </div>

                {/* Direct Firebase Console Links */}
                <div className="pt-2 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                  <a
                    href={firebaseAuthConsoleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold text-[11px] transition-colors"
                  >
                    <span>View Users in Console</span>
                    <ExternalLink className="w-3 h-3 text-slate-400" />
                  </a>

                  <a
                    href={firestoreConsoleUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold text-[11px] transition-colors"
                  >
                    <span>View Firestore Data</span>
                    <ExternalLink className="w-3 h-3 text-slate-400" />
                  </a>
                </div>
              </div>

              {/* Data & File Storage Transparency */}
              <div className="space-y-2 border border-slate-200 rounded-lg p-3.5 bg-white">
                <div className="font-bold text-slate-900 pb-1.5 border-b border-slate-100 uppercase tracking-wider text-[10px] text-slate-500 flex items-center justify-between">
                  <span>What is Saved in Firebase?</span>
                  <span className="text-[10px] text-indigo-600 font-semibold">Firestore Cloud Sync</span>
                </div>

                <div className="space-y-2 text-[11px] pt-1">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-slate-800">Extracted Invoices & Line Items: </span>
                      <span className="text-slate-600">
                        Saved in Firestore under <code className="bg-slate-100 px-1 py-0.2 rounded font-mono text-[10px] text-slate-700">/users/{'{uid}'}/invoices</code> (Vendor, GSTIN, Invoice #, Date, Taxable Value, CGST, SGST, IGST, Line Items).
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-slate-800">Reconciliation Audits: </span>
                      <span className="text-slate-600">
                        Saved in Firestore under <code className="bg-slate-100 px-1 py-0.2 rounded font-mono text-[10px] text-slate-700">/users/{'{uid}'}/reconciliations</code> (Match rates, matched vouchers, discrepancies in ₹).
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 bg-amber-50/60 p-2 rounded border border-amber-200/60">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-slate-800">Raw Files (PDF / Image Binary): </span>
                      <span className="text-slate-600">
                        <strong className="text-amber-800 font-semibold">Not saved in Firebase.</strong> Files are processed in browser memory and passed to Gemini AI for extraction. They are not stored in Firestore due to Firestore's strict 1MB document size limit and client privacy.
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="py-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <UserIcon className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">Not Signed In</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Sign in with your Google account to view login details and sync reconciliation audits to Firebase.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onSignIn();
                }}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                <span>Sign in with Google</span>
              </button>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          {currentUser ? (
            <button
              onClick={() => {
                onClose();
                onSignOut();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-md transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          ) : (
            <div />
          )}

          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200 bg-slate-100 rounded-md transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
