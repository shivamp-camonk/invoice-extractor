import React from 'react';
import { FileSpreadsheet, Sparkles, IndianRupee, Cloud, CloudUpload, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { User } from 'firebase/auth';

interface HeaderProps {
  activeTab: 'reconcile' | 'invoices' | 'ledger' | 'settings';
  setActiveTab: (tab: 'reconcile' | 'invoices' | 'ledger' | 'settings') => void;
  onExportExcel: () => void;
  onLoadSampleData: () => void;
  hasReconciliationData: boolean;
  isProcessing: boolean;
  currentUser: User | null;
  onSignIn: () => void;
  onSignOut: () => void;
  onSaveToCloud: () => void;
  isSavingToCloud: boolean;
  onViewSavedSessions?: () => void;
  savedSessionsCount?: number;
  onOpenProfile?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onExportExcel,
  onLoadSampleData,
  hasReconciliationData,
  isProcessing,
  currentUser,
  onSignIn,
  onSignOut,
  onSaveToCloud,
  isSavingToCloud,
  onViewSavedSessions,
  savedSessionsCount = 0,
  onOpenProfile,
}) => {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30 shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-6">
          {/* Zone 1: Single element Brand wordmark in display face */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold shadow-xs">
              <IndianRupee className="w-4.5 h-4.5 text-white" />
            </div>
            <div>
              <a
                href="/"
                className="text-base sm:text-lg font-bold tracking-tight text-slate-900 hover:text-slate-800 transition-colors whitespace-nowrap flex items-center gap-1.5"
              >
                <span>LedgerMatch GST</span>
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-indigo-50 text-indigo-700 px-1.5 py-0.2 rounded border border-indigo-200/60 hidden sm:inline-block">
                  India (₹)
                </span>
              </a>
            </div>
          </div>

          {/* Zone 2: Navigation tabs */}
          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('reconcile')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap py-1 border-b-2 cursor-pointer ${
                activeTab === 'reconcile'
                  ? 'border-indigo-600 text-indigo-600 font-semibold'
                  : 'border-transparent text-slate-600'
              }`}
            >
              Reconciliation Hub
            </button>
            <button
              onClick={() => setActiveTab('invoices')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap py-1 border-b-2 cursor-pointer ${
                activeTab === 'invoices'
                  ? 'border-indigo-600 text-indigo-600 font-semibold'
                  : 'border-transparent text-slate-600'
              }`}
            >
              Upload Invoices & OCR
            </button>
            <button
              onClick={() => setActiveTab('ledger')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap py-1 border-b-2 cursor-pointer ${
                activeTab === 'ledger'
                  ? 'border-indigo-600 text-indigo-600 font-semibold'
                  : 'border-transparent text-slate-600'
              }`}
            >
              Purchase Ledger (Excel)
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap py-1 border-b-2 cursor-pointer ${
                activeTab === 'settings'
                  ? 'border-indigo-600 text-indigo-600 font-semibold'
                  : 'border-transparent text-slate-600'
              }`}
            >
              GST Rules
            </button>
          </nav>

          {/* Zone 3: Actions & Firebase Authentication */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onLoadSampleData}
              title="Load Indian sample invoices (TCS, Infosys, Reliance) and ledger in ₹"
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors whitespace-nowrap cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Demo Data</span>
            </button>

            {currentUser && onViewSavedSessions && (
              <button
                onClick={onViewSavedSessions}
                title="View your saved reconciliation audits in Firebase Cloud"
                className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:text-indigo-600 bg-slate-100 hover:bg-indigo-50 border border-slate-200 rounded-md transition-colors whitespace-nowrap cursor-pointer"
              >
                <Cloud className="w-3.5 h-3.5 text-indigo-600" />
                <span>Saved Audits</span>
                {savedSessionsCount > 0 && (
                  <span className="ml-0.5 px-1.5 py-0.2 text-[10px] bg-indigo-600 text-white rounded-full font-bold">
                    {savedSessionsCount}
                  </span>
                )}
              </button>
            )}

            {hasReconciliationData && (
              <button
                onClick={onSaveToCloud}
                disabled={isSavingToCloud}
                title="Save this reconciliation audit to Firebase Cloud"
                className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-md transition-colors whitespace-nowrap cursor-pointer"
              >
                <CloudUpload className="w-3.5 h-3.5 text-indigo-600" />
                <span>{isSavingToCloud ? 'Saving...' : 'Cloud Save'}</span>
              </button>
            )}

            <button
              onClick={onExportExcel}
              disabled={!hasReconciliationData || isProcessing}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer shadow-xs ${
                hasReconciliationData && !isProcessing
                  ? 'text-white bg-slate-900 hover:bg-slate-800'
                  : 'text-slate-400 bg-slate-100 cursor-not-allowed'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export Excel</span>
            </button>

            {/* Firebase Auth Account Button */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 pl-2 border-l border-slate-200">
                <button
                  onClick={onOpenProfile}
                  className="flex items-center gap-2 p-1 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer text-left"
                  title="Click to view full login details, Firebase UID, and database info"
                >
                  {currentUser.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt={currentUser.displayName || 'User'}
                      className="w-7 h-7 rounded-full border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shrink-0">
                      {currentUser.displayName ? currentUser.displayName[0].toUpperCase() : 'U'}
                    </div>
                  )}
                  <div className="hidden xl:flex flex-col text-left max-w-[120px]">
                    <span className="text-xs font-bold text-slate-900 leading-tight truncate">
                      {currentUser.displayName || 'My Profile'}
                    </span>
                    <span className="text-[10px] text-slate-500 leading-tight truncate">
                      {currentUser.email}
                    </span>
                  </div>
                </button>
                <button
                  onClick={onSignOut}
                  title={`Signed in as ${currentUser.email}. Click to sign out.`}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={onSignIn}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-2xs"
                title="Sign in with Google to view account details and sync invoices"
              >
                <LogIn className="w-3.5 h-3.5 text-indigo-600" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
