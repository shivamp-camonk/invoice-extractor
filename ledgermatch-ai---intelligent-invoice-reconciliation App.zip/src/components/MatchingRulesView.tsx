import React from 'react';
import { Sliders, CheckCircle2, Shield, AlertCircle, IndianRupee } from 'lucide-react';
import { MatchingSettings } from '../types/reconciliation';

interface MatchingRulesViewProps {
  settings: MatchingSettings;
  onUpdateSettings: (settings: MatchingSettings) => void;
  onRunReconciliation: () => void;
}

export const MatchingRulesView: React.FC<MatchingRulesViewProps> = ({
  settings,
  onUpdateSettings,
  onRunReconciliation,
}) => {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="border-b border-slate-200 pb-3">
        <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <span>Indian GST Reconciliation Rules & Tolerance</span>
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Configure how the LedgerMatch engine pairs extracted GST invoices against your General / Purchase Ledger records.
        </p>
      </div>

      <div className="bg-white rounded-lg border border-slate-200 shadow-xs divide-y divide-slate-200 text-xs">
        {/* Rule 1: Amount Tolerance in ₹ */}
        <div className="p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="max-w-xl">
            <h4 className="font-semibold text-slate-900 text-sm">Currency & Rounding Tolerance (₹)</h4>
            <p className="text-slate-500 mt-1">
              Maximum allowable difference in rupees between the invoice gross total and ledger amount before flagging an item as
              <span className="text-amber-700 font-semibold"> Mismatched</span>.
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              Recommended: ₹1.00 for normal GST decimal round-off (Rule 54 of CGST Rules), or ₹0.10 for strict audits.
            </p>
          </div>

          <div className="sm:w-48 shrink-0">
            <div className="relative">
              <span className="absolute left-2.5 top-2 text-slate-400 font-mono">₹</span>
              <input
                type="number"
                step="0.50"
                min="0"
                value={settings.amountTolerance}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    amountTolerance: Math.max(0, parseFloat(e.target.value) || 0),
                  })
                }
                className="w-full pl-6 pr-3 py-1.5 border border-slate-300 rounded font-mono font-medium text-slate-900 text-xs bg-white focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Rule 2: Separate CGST, SGST, IGST Reconciliation */}
        <div className="p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="max-w-xl">
            <h4 className="font-semibold text-slate-900 text-sm">Strict GST Tax Head Verification</h4>
            <p className="text-slate-500 mt-1">
              Reconciles CGST, SGST, and IGST individually. If an invoice has inter-state IGST but the ledger booked intra-state CGST+SGST (or wrong rates like 12% vs 18%), it will flag a <span className="text-amber-700 font-semibold">Mismatched</span> status.
            </p>
          </div>

          <div className="sm:w-48 shrink-0 flex items-center justify-end">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.requireGstBreakdownMatch}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    requireGstBreakdownMatch: e.target.checked,
                  })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-slate-900"></div>
            </label>
          </div>
        </div>

        {/* Rule 3: Invoice Number Normalization */}
        <div className="p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="max-w-xl">
            <h4 className="font-semibold text-slate-900 text-sm">Indian Invoice Number Normalization</h4>
            <p className="text-slate-500 mt-1">
              Ignores slash, hyphen, and standard financial year prefix differences (e.g. <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">INV/2026/089</code> matches <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">INV-2026-089</code> or <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">2026089</code>).
            </p>
          </div>

          <div className="sm:w-48 shrink-0 flex items-center justify-end">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.normalizeInvoiceNumbers}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    normalizeInvoiceNumbers: e.target.checked,
                  })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-slate-900"></div>
            </label>
          </div>
        </div>

        {/* Rule 4: Fuzzy Vendor / Party Name Matching */}
        <div className="p-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="max-w-xl">
            <h4 className="font-semibold text-slate-900 text-sm">Fuzzy Supplier / Vendor Matching</h4>
            <p className="text-slate-500 mt-1">
              Accounts for abbreviations like "Pvt Ltd" vs "Private Limited" or "TCS" vs "Tata Consultancy Services Ltd".
            </p>
          </div>

          <div className="sm:w-48 shrink-0 flex items-center justify-end">
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.fuzzyVendorMatching}
                onChange={(e) =>
                  onUpdateSettings({
                    ...settings,
                    fuzzyVendorMatching: e.target.checked,
                  })
                }
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-slate-900"></div>
            </label>
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <button
          onClick={onRunReconciliation}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition-colors cursor-pointer"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Apply Rules & Recalculate GST Matching</span>
        </button>
      </div>
    </div>
  );
};
