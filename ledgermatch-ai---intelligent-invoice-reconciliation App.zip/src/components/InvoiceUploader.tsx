import React, { useRef, useState } from 'react';
import {
  UploadCloud,
  FileText,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Trash2,
  Eye,
  Edit3,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  IndianRupee,
} from 'lucide-react';
import { ExtractedInvoice } from '../types/reconciliation';
import { formatINR } from '../utils/matchingEngine';

interface InvoiceUploaderProps {
  invoices: ExtractedInvoice[];
  onUploadFiles: (files: File[]) => void;
  onExtractInvoice: (invoiceId: string) => void;
  onExtractAllPending: () => void;
  onDeleteInvoice: (invoiceId: string) => void;
  onSelectInvoice: (invoice: ExtractedInvoice) => void;
  onLoadSampleInvoices: () => void;
  isProcessing: boolean;
  onProceedToLedger: () => void;
}

export const InvoiceUploader: React.FC<InvoiceUploaderProps> = ({
  invoices,
  onUploadFiles,
  onExtractInvoice,
  onExtractAllPending,
  onDeleteInvoice,
  onSelectInvoice,
  onLoadSampleInvoices,
  isProcessing,
  onProceedToLedger,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const fileList = Array.from(e.dataTransfer.files);
      const validFiles = fileList.filter(
        f => f.type === 'application/pdf' || f.type.startsWith('image/')
      );
      if (validFiles.length > 0) {
        onUploadFiles(validFiles);
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const fileList = Array.from(e.target.files);
      onUploadFiles(fileList);
      e.target.value = '';
    }
  };

  const pendingCount = invoices.filter(i => i.status === 'pending').length;
  const extractedCount = invoices.filter(i => i.status === 'extracted').length;
  const totalAmount = invoices
    .filter(i => i.status === 'extracted')
    .reduce((sum, inv) => sum + inv.totalAmount, 0);

  const totalGst = invoices
    .filter(i => i.status === 'extracted')
    .reduce((sum, inv) => sum + inv.taxAmount, 0);

  return (
    <div className="space-y-6">
      {/* Step Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>1. Upload Invoices (PDF / Image)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Upload vendor tax invoices. AI OCR automatically extracts Vendor, GSTIN, Invoice #, Date, Taxable Value, CGST, SGST, IGST & Total Amount (₹).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onLoadSampleInvoices}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer shadow-2xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Load 5 Indian Sample Invoices</span>
          </button>

          {pendingCount > 0 && (
            <button
              onClick={onExtractAllPending}
              disabled={isProcessing}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors cursor-pointer shadow-xs disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Extracting GST Data...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Process All Pending ({pendingCount})</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-xl p-7 text-center transition-all cursor-pointer ${
          isDragging
            ? 'border-indigo-600 bg-indigo-50/40 scale-[0.99]'
            : 'border-slate-300 hover:border-slate-400 bg-white'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="application/pdf,image/png,image/jpeg,image/webp"
          className="hidden"
          onChange={handleFileInputChange}
        />

        <div className="flex flex-col items-center justify-center space-y-2.5">
          <div className="w-11 h-11 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600">
            <UploadCloud className="w-6 h-6 text-indigo-600" />
          </div>

          <div>
            <p className="text-sm font-bold text-slate-900">
              Drag & drop Indian invoice files here, or <span className="text-indigo-600 hover:underline">browse files</span>
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Supports Tax Invoices in PDF, PNG, JPG, or WebP formats (single or batch upload)
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
            <span className="flex items-center gap-1 text-slate-700 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Auto-Extracts:
            </span>
            <span>Supplier GSTIN</span>
            <span>·</span>
            <span>Taxable Value (₹)</span>
            <span>·</span>
            <span className="text-indigo-700 font-semibold">CGST / SGST (Intra-state)</span>
            <span>·</span>
            <span className="text-indigo-700 font-semibold">IGST (Inter-state)</span>
            <span>·</span>
            <span>Grand Total (₹)</span>
          </div>
        </div>
      </div>

      {/* Uploaded Invoices List */}
      {invoices.length > 0 && (
        <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-xs">
          <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3 text-xs font-medium text-slate-700">
              <span className="font-bold text-slate-900">{invoices.length} Invoices Uploaded</span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold">{extractedCount} Extracted</span>
              {pendingCount > 0 && (
                <>
                  <span>·</span>
                  <span className="text-amber-700 font-semibold">{pendingCount} Pending OCR</span>
                </>
              )}
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold text-slate-900 font-mono tabular-nums">
              <span>Total GST: {formatINR(totalGst)}</span>
              <span>·</span>
              <span className="text-indigo-900 font-bold">Total Invoiced: {formatINR(totalAmount)}</span>
            </div>
          </div>

          <div className="divide-y divide-slate-100 overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-medium">
                <tr>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Supplier & GSTIN</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3 text-right">Taxable (₹)</th>
                  <th className="py-2.5 px-3 text-right">CGST (₹)</th>
                  <th className="py-2.5 px-3 text-right">SGST (₹)</th>
                  <th className="py-2.5 px-3 text-right">IGST (₹)</th>
                  <th className="py-2.5 px-3 text-right font-bold">Total (₹)</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map((invoice) => {
                  return (
                    <tr
                      key={invoice.id}
                      className="hover:bg-slate-50 transition-colors group cursor-pointer"
                      onClick={() => onSelectInvoice(invoice)}
                    >
                      {/* Status */}
                      <td className="py-2 px-3 whitespace-nowrap">
                        {invoice.status === 'extracted' && (
                          <div className="flex items-center gap-1.5 text-emerald-700 font-semibold text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                            <span>Extracted</span>
                          </div>
                        )}
                        {invoice.status === 'processing' && (
                          <div className="flex items-center gap-1.5 text-indigo-600 font-medium text-[11px]">
                            <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
                            <span>Scanning...</span>
                          </div>
                        )}
                        {invoice.status === 'pending' && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onExtractInvoice(invoice.id);
                            }}
                            className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 font-semibold text-[11px] underline"
                          >
                            <span>Run AI OCR</span>
                          </button>
                        )}
                        {invoice.status === 'error' && (
                          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center gap-1 text-rose-600 text-[11px]" title={invoice.errorMessage}>
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              <span>Failed</span>
                            </div>
                            <button
                              onClick={() => onExtractInvoice(invoice.id)}
                              className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold underline ml-1 cursor-pointer"
                            >
                              Retry
                            </button>
                            <button
                              onClick={() => onSelectInvoice(invoice)}
                              className="text-[11px] text-slate-600 hover:text-slate-900 font-semibold underline ml-1 cursor-pointer"
                            >
                              Edit
                            </button>
                          </div>
                        )}
                      </td>

                      {/* Invoice # */}
                      <td className="py-2 px-3 whitespace-nowrap font-mono font-medium text-slate-900">
                        {invoice.status === 'extracted' ? invoice.invoiceNumber : '—'}
                      </td>

                      {/* Supplier & GSTIN */}
                      <td className="py-2 px-3 whitespace-nowrap max-w-[220px]">
                        {invoice.status === 'extracted' ? (
                          <div>
                            <span className="font-semibold text-slate-900 block truncate" title={invoice.vendorName}>
                              {invoice.vendorName}
                            </span>
                            {invoice.vendorGstin && (
                              <span className="text-[10px] font-mono text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded border border-indigo-100">
                                {invoice.vendorGstin}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">Pending OCR</span>
                        )}
                      </td>

                      {/* Date */}
                      <td className="py-2 px-3 whitespace-nowrap text-slate-600 font-mono text-[11px]">
                        {invoice.status === 'extracted' ? invoice.invoiceDate : '—'}
                      </td>

                      {/* Taxable Value */}
                      <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-700">
                        {invoice.status === 'extracted' ? formatINR(invoice.subtotal) : '—'}
                      </td>

                      {/* CGST */}
                      <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-600">
                        {invoice.status === 'extracted' ? (invoice.cgst > 0 ? formatINR(invoice.cgst) : '—') : '—'}
                      </td>

                      {/* SGST */}
                      <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-600">
                        {invoice.status === 'extracted' ? (invoice.sgst > 0 ? formatINR(invoice.sgst) : '—') : '—'}
                      </td>

                      {/* IGST */}
                      <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-600">
                        {invoice.status === 'extracted' ? (invoice.igst > 0 ? formatINR(invoice.igst) : '—') : '—'}
                      </td>

                      {/* Grand Total Amount */}
                      <td className="py-2 px-3 whitespace-nowrap text-right font-mono font-bold tabular-nums text-slate-900">
                        {invoice.status === 'extracted' ? formatINR(invoice.totalAmount) : '—'}
                      </td>

                      {/* Actions */}
                      <td className="py-2 px-3 whitespace-nowrap text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onSelectInvoice(invoice)}
                            title="Inspect voucher and edit fields"
                            className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteInvoice(invoice.id)}
                            title="Remove invoice"
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Click any row to view document voucher and edit GST breakdown
            </span>

            {extractedCount > 0 && (
              <button
                onClick={onProceedToLedger}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer shadow-xs"
              >
                <span>Proceed to Step 3: Purchase Ledger</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
