import React from 'react';
import { Cloud, X, Calendar, CheckCircle2, AlertTriangle, Trash2, ArrowUpRight, FolderOpen } from 'lucide-react';
import { formatINR } from '../utils/matchingEngine';

export interface SavedSessionItem {
  id: string;
  userId: string;
  title: string;
  totalInvoices: number;
  totalLedgerRecords: number;
  matchedCount: number;
  mismatchedCount: number;
  notInLedgerCount: number;
  matchRatePercent: number;
  totalInvoiceAmount: number;
  totalDiscrepancyAmount: number;
  createdAt: string;
  invoicesData?: any[];
  ledgerData?: any[];
}

interface SavedSessionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: SavedSessionItem[];
  onLoadSession: (session: SavedSessionItem) => void;
  onDeleteSession: (sessionId: string) => void;
  isLoading: boolean;
}

export const SavedSessionsModal: React.FC<SavedSessionsModalProps> = ({
  isOpen,
  onClose,
  sessions,
  onLoadSession,
  onDeleteSession,
  isLoading,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-2xl w-full overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Cloud className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Cloud Saved Reconciliation Audits</h3>
              <p className="text-xs text-slate-500">Stored securely in your Firebase Firestore account</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-3">
          {isLoading ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              <div className="animate-spin w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full mx-auto mb-2" />
              Loading saved sessions from Firestore...
            </div>
          ) : sessions.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <FolderOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <div className="text-xs font-semibold text-slate-700">No saved sessions yet</div>
              <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                After reconciling invoices against your ledger, click &quot;Cloud Save&quot; in the header to save audit snapshots.
              </p>
            </div>
          ) : (
            sessions.map((sess) => (
              <div
                key={sess.id}
                className="p-4 rounded-lg border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/20 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{sess.title}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                      {sess.matchRatePercent.toFixed(0)}% Match
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {new Date(sess.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span>·</span>
                    <span>{sess.totalInvoices} Invoices ({formatINR(sess.totalInvoiceAmount)})</span>
                    <span>·</span>
                    <span className="flex items-center gap-1 text-emerald-700">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" /> {sess.matchedCount} Matched
                    </span>
                    {sess.mismatchedCount > 0 && (
                      <span className="flex items-center gap-1 text-amber-700">
                        <AlertTriangle className="w-3 h-3 text-amber-600" /> {sess.mismatchedCount} Mismatch
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onLoadSession(sess)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-md transition-colors cursor-pointer"
                  >
                    <span>Restore</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteSession(sess.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                    title="Delete saved session"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>{sessions.length} session(s) saved in Firestore</span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-200 bg-slate-100 rounded-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
