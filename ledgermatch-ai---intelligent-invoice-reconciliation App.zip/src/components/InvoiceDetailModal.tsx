import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  AlertTriangle,
  FileQuestion,
  FileText,
  Edit2,
  Save,
  AlertCircle,
} from 'lucide-react';
import { ExtractedInvoice, ReconciliationItem } from '../types/reconciliation';
import { formatINR } from '../utils/matchingEngine';

interface InvoiceDetailModalProps {
  item: ReconciliationItem | null;
  invoice: ExtractedInvoice | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateInvoice: (updatedInvoice: ExtractedInvoice) => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  item,
  invoice: propInvoice,
  isOpen,
  onClose,
  onUpdateInvoice,
}) => {
  if (!isOpen) return null;

  const invoice = propInvoice || item?.invoice;
  const ledger = item?.ledger;

  const [isEditing, setIsEditing] = useState(false);
  const [vendorName, setVendorName] = useState(invoice?.vendorName || '');
  const [vendorGstin, setVendorGstin] = useState(invoice?.vendorGstin || '');
  const [invoiceNumber, setInvoiceNumber] = useState(invoice?.invoiceNumber || '');
  const [invoiceDate, setInvoiceDate] = useState(invoice?.invoiceDate || '');
  const [subtotal, setSubtotal] = useState(invoice?.subtotal ? String(invoice.subtotal) : '0');
  const [cgst, setCgst] = useState(invoice?.cgst !== undefined ? String(invoice.cgst) : '0');
  const [sgst, setSgst] = useState(invoice?.sgst !== undefined ? String(invoice.sgst) : '0');
  const [igst, setIgst] = useState(invoice?.igst !== undefined ? String(invoice.igst) : '0');
  const [totalAmount, setTotalAmount] = useState(invoice?.totalAmount ? String(invoice.totalAmount) : '0');
  const [notes, setNotes] = useState(invoice?.notes || '');

  const handleSaveEdits = () => {
    if (!invoice) return;
    const numSubtotal = parseFloat(subtotal) || 0;
    const numCgst = parseFloat(cgst) || 0;
    const numSgst = parseFloat(sgst) || 0;
    const numIgst = parseFloat(igst) || 0;
    const totalGst = numCgst + numSgst + numIgst;
    const numTotal = parseFloat(totalAmount) || (numSubtotal + totalGst);

    const updated: ExtractedInvoice = {
      ...invoice,
      vendorName: vendorName.trim(),
      vendorGstin: vendorGstin.trim().toUpperCase() || undefined,
      invoiceNumber: invoiceNumber.trim(),
      invoiceDate: invoiceDate.trim(),
      subtotal: numSubtotal,
      cgst: numCgst,
      sgst: numSgst,
      igst: numIgst,
      taxAmount: totalGst,
      totalAmount: numTotal,
      notes: notes.trim(),
      isManuallyEdited: true,
    };
    onUpdateInvoice(updated);
    setIsEditing(false);
  };

  const status = item?.status || (invoice ? 'NOT_IN_LEDGER' : 'NOT_IN_INVOICES');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in-50 duration-150">
        {/* Modal Top Header */}
        <div className="px-6 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-mono text-xs font-bold">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">
                  {invoice ? `Invoice #${invoice.invoiceNumber}` : `Ledger Voucher: ${ledger?.invoiceNumber}`}
                </h3>
                {invoice?.isManuallyEdited && (
                  <span className="text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded font-semibold">
                    Manually Edited
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                {invoice?.vendorName || ledger?.vendorName} · Indian GST Audit Verification
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!isEditing && invoice && (
              <button
                onClick={() => setIsEditing(true)}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5 text-slate-500" />
                <span>Edit GST Details</span>
              </button>
            )}

            {isEditing && (
              <button
                onClick={handleSaveEdits}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Two-Column Split */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          {/* Left Column (5 cols): Document Viewer */}
          <div className="lg:col-span-5 p-5 bg-slate-50/60 flex flex-col">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Source Document Voucher
              </span>
              {invoice?.confidenceScore && (
                <span className="text-[11px] text-slate-500 font-mono">
                  OCR Score: {Math.round(invoice.confidenceScore * 100)}%
                </span>
              )}
            </div>

            <div className="flex-1 bg-white rounded-lg border border-slate-200 shadow-xs p-2 overflow-hidden flex flex-col items-center justify-center min-h-[360px] relative">
              {invoice?.fileDataUrl ? (
                <div className="w-full h-full max-h-[500px] overflow-auto rounded border border-slate-100">
                  <img
                    src={invoice.fileDataUrl}
                    alt={`Invoice ${invoice.invoiceNumber}`}
                    className="w-full h-auto object-contain"
                  />
                </div>
              ) : (
                <div className="text-center p-6 text-slate-400">
                  <FileText className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                  <p className="text-xs font-medium text-slate-600">Tax Invoice Document</p>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {invoice?.fileName || 'No preview available'}
                  </p>
                </div>
              )}
            </div>

            {/* Extracted Line Items */}
            {invoice?.lineItems && invoice.lineItems.length > 0 && (
              <div className="mt-3.5">
                <span className="text-xs font-bold text-slate-700 block mb-1.5">
                  Line Items & HSN/SAC ({invoice.lineItems.length}):
                </span>
                <div className="bg-white rounded border border-slate-200 overflow-hidden text-[11px]">
                  <table className="w-full divide-y divide-slate-100">
                    <thead className="bg-slate-50 text-slate-500 font-medium">
                      <tr>
                        <th className="py-1.5 px-2 text-left">Description</th>
                        <th className="py-1.5 px-2 text-center w-16">HSN/SAC</th>
                        <th className="py-1.5 px-2 text-right w-20">Amount (₹)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {invoice.lineItems.map((it, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="py-1.5 px-2 text-slate-700 truncate max-w-[140px]">{it.description}</td>
                          <td className="py-1.5 px-2 text-center text-slate-500 font-mono">
                            {it.hsnSac || '—'}
                          </td>
                          <td className="py-1.5 px-2 text-right font-mono font-medium text-slate-900">
                            {formatINR(it.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Right Column (7 cols): Indian GST Side-by-Side Diff Comparison */}
          <div className="lg:col-span-7 p-6 space-y-5">
            {/* Reconciliation Status Card */}
            <div
              className={`p-3.5 rounded-lg border flex items-start gap-3 ${
                status === 'MATCHED'
                  ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                  : status === 'MISMATCHED'
                  ? 'bg-amber-50/70 border-amber-200 text-amber-900'
                  : status === 'NOT_IN_LEDGER'
                  ? 'bg-rose-50/70 border-rose-200 text-rose-900'
                  : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}
            >
              <div className="mt-0.5">
                {status === 'MATCHED' && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                {status === 'MISMATCHED' && <AlertTriangle className="w-5 h-5 text-amber-600" />}
                {status === 'NOT_IN_LEDGER' && <FileQuestion className="w-5 h-5 text-rose-600" />}
                {status === 'NOT_IN_INVOICES' && <AlertCircle className="w-5 h-5 text-slate-600" />}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider">
                    Status: {status.replace(/_/g, ' ')}
                  </h4>
                  {item?.matchMethod && (
                    <span className="text-[10px] text-slate-500 font-mono">
                      Matched by: {item.matchMethod.replace(/_/g, ' ')}
                    </span>
                  )}
                </div>

                <p className="text-xs mt-1">
                  {status === 'MATCHED' &&
                    'Invoice values match General Ledger entries within tolerance. Input Tax Credit (ITC) can be safely claimed.'}
                  {status === 'MISMATCHED' &&
                    'Discrepancies identified in Bill Amount, CGST, SGST, or IGST. Review the field differences below before GSTR-3B filing.'}
                  {status === 'NOT_IN_LEDGER' &&
                    'This tax invoice was processed by OCR, but has no corresponding entry in your Purchase Register.'}
                  {status === 'NOT_IN_INVOICES' &&
                    'This entry exists in your Purchase Ledger, but no matching tax invoice voucher was uploaded.'}
                </p>

                {item?.discrepancies && item.discrepancies.length > 0 && (
                  <ul className="mt-2 space-y-1 text-xs">
                    {item.discrepancies.map((d, i) => (
                      <li key={i} className="flex items-start gap-1.5 font-semibold text-amber-900">
                        <span>•</span>
                        <span>{d.message}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Field-by-Field Diff Comparison Table */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Field-by-Field GST Audit
                </span>
                <span className="text-[11px] text-slate-500">
                  Tolerance: ₹1.00
                </span>
              </div>

              <div className="bg-white rounded-lg border border-slate-200 overflow-hidden text-xs">
                <table className="min-w-full divide-y divide-slate-200">
                  <thead className="bg-slate-50 text-slate-600 font-medium">
                    <tr>
                      <th className="py-2 px-3 text-left w-36">Field</th>
                      <th className="py-2 px-3 text-left">Invoice (OCR)</th>
                      <th className="py-2 px-3 text-left">General Ledger</th>
                      <th className="py-2 px-3 text-right w-24">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {/* 1. Supplier Name */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">Supplier Name</td>
                      <td className="py-2 px-3 font-sans">
                        {isEditing ? (
                          <input
                            type="text"
                            value={vendorName}
                            onChange={(e) => setVendorName(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white text-slate-900 font-sans"
                          />
                        ) : (
                          <span className="text-slate-900 font-semibold">{invoice?.vendorName || '—'}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 font-sans text-slate-700">
                        {ledger?.vendorName || <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {ledger ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 2. Supplier GSTIN */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">Supplier GSTIN</td>
                      <td className="py-2 px-3">
                        {isEditing ? (
                          <input
                            type="text"
                            value={vendorGstin}
                            onChange={(e) => setVendorGstin(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono uppercase"
                          />
                        ) : (
                          <span className="text-indigo-700 font-bold">{invoice?.vendorGstin || '—'}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-slate-700">
                        {ledger?.vendorGstin || <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {invoice?.vendorGstin && ledger?.vendorGstin && invoice.vendorGstin === ledger.vendorGstin ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 3. Invoice # */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">Invoice / Bill #</td>
                      <td className="py-2 px-3">
                        {isEditing ? (
                          <input
                            type="text"
                            value={invoiceNumber}
                            onChange={(e) => setInvoiceNumber(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono"
                          />
                        ) : (
                          <span className="text-slate-900 font-semibold">{invoice?.invoiceNumber || '—'}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-slate-700">
                        {ledger?.invoiceNumber || <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {ledger ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 4. Taxable Value */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">Taxable Value (₹)</td>
                      <td className="py-2 px-3 tabular-nums">
                        {isEditing ? (
                          <input
                            type="number"
                            step="1"
                            value={subtotal}
                            onChange={(e) => setSubtotal(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono"
                          />
                        ) : (
                          <span>{formatINR(invoice?.subtotal || 0)}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 tabular-nums text-slate-700">
                        {ledger ? formatINR(ledger.taxableAmount || 0) : <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {ledger ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 5. CGST */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">CGST (₹)</td>
                      <td className="py-2 px-3 tabular-nums">
                        {isEditing ? (
                          <input
                            type="number"
                            step="1"
                            value={cgst}
                            onChange={(e) => setCgst(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono"
                          />
                        ) : (
                          <span>{invoice?.cgst ? formatINR(invoice.cgst) : '₹0.00'}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 tabular-nums text-slate-700">
                        {ledger ? (ledger.cgst ? formatINR(ledger.cgst) : '₹0.00') : <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {ledger && Math.abs((invoice?.cgst || 0) - (ledger.cgst || 0)) <= 1.0 ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : ledger ? (
                          <span className="text-amber-700 font-sans text-[11px] font-semibold">Diff</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 6. SGST */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">SGST (₹)</td>
                      <td className="py-2 px-3 tabular-nums">
                        {isEditing ? (
                          <input
                            type="number"
                            step="1"
                            value={sgst}
                            onChange={(e) => setSgst(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono"
                          />
                        ) : (
                          <span>{invoice?.sgst ? formatINR(invoice.sgst) : '₹0.00'}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 tabular-nums text-slate-700">
                        {ledger ? (ledger.sgst ? formatINR(ledger.sgst) : '₹0.00') : <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {ledger && Math.abs((invoice?.sgst || 0) - (ledger.sgst || 0)) <= 1.0 ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : ledger ? (
                          <span className="text-amber-700 font-sans text-[11px] font-semibold">Diff</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 7. IGST */}
                    <tr className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-sans font-medium text-slate-700">IGST (₹)</td>
                      <td className="py-2 px-3 tabular-nums">
                        {isEditing ? (
                          <input
                            type="number"
                            step="1"
                            value={igst}
                            onChange={(e) => setIgst(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono"
                          />
                        ) : (
                          <span>{invoice?.igst ? formatINR(invoice.igst) : '₹0.00'}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 tabular-nums text-slate-700">
                        {ledger ? (ledger.igst ? formatINR(ledger.igst) : '₹0.00') : <span className="text-slate-400 italic font-sans">Not in Ledger</span>}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {ledger && Math.abs((invoice?.igst || 0) - (ledger.igst || 0)) <= 1.0 ? (
                          <span className="text-emerald-700 font-sans text-[11px] font-semibold">Matched</span>
                        ) : ledger ? (
                          <span className="text-amber-700 font-sans text-[11px] font-semibold">Diff: {formatINR((invoice?.igst || 0) - (ledger.igst || 0))}</span>
                        ) : (
                          <span className="text-slate-400 font-sans text-[11px]">—</span>
                        )}
                      </td>
                    </tr>

                    {/* 8. Total Bill Amount */}
                    <tr className="bg-slate-50/80 font-bold text-slate-900">
                      <td className="py-2.5 px-3 font-sans">Total Bill Amount (₹)</td>
                      <td className="py-2.5 px-3 tabular-nums text-slate-900">
                        {isEditing ? (
                          <input
                            type="number"
                            step="1"
                            value={totalAmount}
                            onChange={(e) => setTotalAmount(e.target.value)}
                            className="w-full px-2 py-1 text-xs border rounded bg-white font-mono font-bold"
                          />
                        ) : (
                          <span>{formatINR(invoice?.totalAmount || 0)}</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 tabular-nums text-slate-900">
                        {ledger ? formatINR(ledger.amount) : (
                          <span className="text-slate-400 italic font-sans font-normal">Not in Ledger</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {ledger && Math.abs((invoice?.totalAmount || 0) - ledger.amount) <= 1.0 ? (
                          <span className="text-emerald-700 font-sans text-xs font-bold">Matched</span>
                        ) : ledger ? (
                          <span className="text-rose-700 font-sans text-xs font-bold">
                            Diff: {formatINR((invoice?.totalAmount || 0) - ledger.amount)}
                          </span>
                        ) : (
                          <span className="text-rose-600 font-sans text-xs font-bold">Unrecorded</span>
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Audit Guidance Note */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs">
              <span className="font-bold text-slate-800 block mb-1">Chartered Accountant (CA) Audit Recommendation:</span>
              <p className="text-slate-600">
                {status === 'MATCHED' &&
                  'All GST components (CGST, SGST, IGST) and gross amounts match your purchase ledger. Input Tax Credit (ITC) can be claimed in GSTR-3B.'}
                {status === 'MISMATCHED' &&
                  'Tax breakdown or total amount variance found. Review GSTR-2B or contact vendor to correct tax invoice before booking.'}
                {status === 'NOT_IN_LEDGER' &&
                  'Invoice missing in accounting books. Book purchase entry in Tally / ERP with correct HSN/SAC and GST percentage.'}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            Indian GST Act 2017 Reconciliation
          </span>

          <div className="flex items-center gap-2">
            {isEditing ? (
              <button
                onClick={handleSaveEdits}
                className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors cursor-pointer"
              >
                Save & Recalculate GST
              </button>
            ) : (
              <button
                onClick={onClose}
                className="px-4 py-1.5 text-xs font-bold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
              >
                Close Audit View
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
