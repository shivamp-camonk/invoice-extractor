import React, { useState, useMemo } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  FileQuestion,
  FileSpreadsheet,
  Download,
  Search,
  Sliders,
  Sparkles,
  Eye,
  FileWarning,
  IndianRupee,
} from 'lucide-react';
import {
  MatchingSettings,
  ReconciliationItem,
  ReconciliationStatus,
  ReconciliationSummary,
} from '../types/reconciliation';
import { formatINR } from '../utils/matchingEngine';

interface ReconciliationDashboardProps {
  items: ReconciliationItem[];
  summary: ReconciliationSummary;
  settings: MatchingSettings;
  onUpdateSettings: (settings: MatchingSettings) => void;
  onExportExcel: () => void;
  onSelectItem: (item: ReconciliationItem) => void;
  onLoadSampleData: () => void;
}

export const ReconciliationDashboard: React.FC<ReconciliationDashboardProps> = ({
  items,
  summary,
  settings,
  onUpdateSettings,
  onExportExcel,
  onSelectItem,
  onLoadSampleData,
}) => {
  const [statusFilter, setStatusFilter] = useState<'ALL' | ReconciliationStatus>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSettingsDrawer, setShowSettingsDrawer] = useState(false);

  // Filter items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (statusFilter !== 'ALL' && item.status !== statusFilter) {
        return false;
      }

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const invNum = (item.invoice?.invoiceNumber || item.ledger?.invoiceNumber || '').toLowerCase();
        const vendor = (item.invoice?.vendorName || item.ledger?.vendorName || '').toLowerCase();
        const gstin = (item.invoice?.vendorGstin || item.ledger?.vendorGstin || '').toLowerCase();
        const notes = item.discrepancies.map((d) => d.message).join(' ').toLowerCase();

        return invNum.includes(query) || vendor.includes(query) || gstin.includes(query) || notes.includes(query);
      }

      return true;
    });
  }, [items, statusFilter, searchQuery]);

  // Export CSV
  const handleExportCsv = () => {
    const headers = [
      'Status',
      'Invoice Number',
      'Supplier Name',
      'Supplier GSTIN',
      'Invoice Date',
      'Taxable Value (INR)',
      'Invoice CGST (INR)',
      'Invoice SGST (INR)',
      'Invoice IGST (INR)',
      'Total GST (INR)',
      'Invoice Total (INR)',
      'Ledger Ref',
      'Ledger Total (INR)',
      'Ledger CGST (INR)',
      'Ledger SGST (INR)',
      'Ledger IGST (INR)',
      'Amount Discrepancy (INR)',
      'Audit Discrepancy Details',
    ];

    const rows = items.map((item) => [
      item.status,
      item.invoice?.invoiceNumber || item.ledger?.invoiceNumber || 'N/A',
      `"${(item.invoice?.vendorName || item.ledger?.vendorName || '').replace(/"/g, '""')}"`,
      item.invoice?.vendorGstin || item.ledger?.vendorGstin || 'N/A',
      item.invoice?.invoiceDate || item.ledger?.date || 'N/A',
      item.invoice ? item.invoice.subtotal.toFixed(2) : 'N/A',
      item.invoice ? item.invoice.cgst.toFixed(2) : 'N/A',
      item.invoice ? item.invoice.sgst.toFixed(2) : 'N/A',
      item.invoice ? item.invoice.igst.toFixed(2) : 'N/A',
      item.invoice ? item.invoice.taxAmount.toFixed(2) : 'N/A',
      item.invoice ? item.invoice.totalAmount.toFixed(2) : 'N/A',
      item.ledger?.invoiceNumber || 'N/A',
      item.ledger ? item.ledger.amount.toFixed(2) : 'N/A',
      item.ledger ? item.ledger.cgst.toFixed(2) : 'N/A',
      item.ledger ? item.ledger.sgst.toFixed(2) : 'N/A',
      item.ledger ? item.ledger.igst.toFixed(2) : 'N/A',
      item.amountVariance !== 0 ? item.amountVariance.toFixed(2) : '0.00',
      `"${item.discrepancies.map((d) => d.message).join('; ').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `GST_Reconciliation_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderStatus = (status: ReconciliationStatus) => {
    switch (status) {
      case 'MATCHED':
        return (
          <div className="inline-flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
            <span>Matched</span>
          </div>
        );
      case 'MISMATCHED':
        return (
          <div className="inline-flex items-center gap-1.5 text-amber-700 font-bold text-xs">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-600" />
            <span>Mismatched</span>
          </div>
        );
      case 'NOT_IN_LEDGER':
        return (
          <div className="inline-flex items-center gap-1.5 text-rose-700 font-bold text-xs">
            <FileQuestion className="w-3.5 h-3.5 shrink-0 text-rose-600" />
            <span>Not in Ledger</span>
          </div>
        );
      case 'NOT_IN_INVOICES':
        return (
          <div className="inline-flex items-center gap-1.5 text-slate-600 font-bold text-xs">
            <FileWarning className="w-3.5 h-3.5 shrink-0 text-slate-500" />
            <span>Missing Invoice</span>
          </div>
        );
    }
  };

  if (items.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-10 text-center max-w-xl mx-auto my-6 shadow-xs">
        <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center mb-3">
          <FileSpreadsheet className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-slate-900">GST Matching Engine Ready</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
          Upload Indian Tax Invoices (PDF/Image) and your Purchase Ledger (Excel) to compare amounts, CGST, SGST, and IGST.
        </p>

        <div className="mt-5 flex items-center justify-center">
          <button
            onClick={onLoadSampleData}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-white" />
            <span>Load Indian Sample Data (₹)</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Executive KPI Summary Cards in INR (₹) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* KPI 1: Reconciliation Rate */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            Reconciliation Rate
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            {summary.matchRatePercent.toFixed(1)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {summary.matchedCount} of {summary.totalInvoices} Invoices Matched
          </div>
        </div>

        {/* KPI 2: Matched ITC Volume */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Matched (₹)
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-emerald-700 mt-1 truncate" title={formatINR(summary.totalMatchedAmount)}>
            {formatINR(summary.totalMatchedAmount)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {summary.matchedCount} bills verified for Input Tax Credit
          </div>
        </div>

        {/* KPI 3: GST & Amount Mismatches */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wider flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-amber-600" /> Mismatches (₹)
          </div>
          <div className="text-xl font-bold font-mono tabular-nums text-amber-700 mt-1 truncate" title={formatINR(summary.totalDiscrepancyAmount)}>
            {formatINR(summary.totalDiscrepancyAmount)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {summary.mismatchedCount} items require correction
          </div>
        </div>

        {/* KPI 4: Unrecorded Invoices (Not in Ledger) */}
        <div className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs">
          <div className="text-[11px] font-bold text-rose-700 uppercase tracking-wider flex items-center gap-1">
            <FileQuestion className="w-3 h-3 text-rose-600" /> Not in Ledger
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-rose-700 mt-1">
            {summary.notInLedgerCount}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Unrecorded bills to post into Books
          </div>
        </div>
      </div>

      {/* Main Reconciliation Table Container */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        {/* Controls Toolbar: Filters + Search + Export */}
        <div className="p-3.5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-50/70">
          {/* Segmented Filter Buttons */}
          <div className="flex items-center gap-1 p-1 bg-slate-200/80 rounded-lg overflow-x-auto">
            <button
              onClick={() => setStatusFilter('ALL')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'ALL'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Records ({items.length})
            </button>
            <button
              onClick={() => setStatusFilter('MATCHED')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'MATCHED'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-emerald-800'
              }`}
            >
              Matched ({summary.matchedCount})
            </button>
            <button
              onClick={() => setStatusFilter('MISMATCHED')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'MISMATCHED'
                  ? 'bg-white text-amber-800 shadow-xs'
                  : 'text-slate-600 hover:text-amber-800'
              }`}
            >
              Mismatches ({summary.mismatchedCount})
            </button>
            <button
              onClick={() => setStatusFilter('NOT_IN_LEDGER')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                statusFilter === 'NOT_IN_LEDGER'
                  ? 'bg-white text-rose-800 shadow-xs'
                  : 'text-slate-600 hover:text-rose-800'
              }`}
            >
              Not in Ledger ({summary.notInLedgerCount})
            </button>
            {summary.notInInvoicesCount > 0 && (
              <button
                onClick={() => setStatusFilter('NOT_IN_INVOICES')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  statusFilter === 'NOT_IN_INVOICES'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Missing Invoice ({summary.notInInvoicesCount})
              </button>
            )}
          </div>

          {/* Search & Actions */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                placeholder="Search vendor, GSTIN, invoice #..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-md text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-48 sm:w-60"
              />
            </div>

            <button
              onClick={() => setShowSettingsDrawer(!showSettingsDrawer)}
              className="p-1.5 text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors"
              title="GST Matching Tolerance"
            >
              <Sliders className="w-4 h-4" />
            </button>

            <button
              onClick={onExportExcel}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer shadow-xs whitespace-nowrap"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export to Excel</span>
            </button>

            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors cursor-pointer whitespace-nowrap"
              title="Download CSV"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>CSV</span>
            </button>
          </div>
        </div>

        {/* Tolerance Drawer */}
        {showSettingsDrawer && (
          <div className="p-3.5 bg-slate-100/70 border-b border-slate-200 text-xs">
            <div className="font-bold text-slate-900 mb-2">GST Matching Parameters:</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-slate-600 block mb-1">
                  Amount Tolerance (₹):
                </label>
                <div className="relative">
                  <span className="absolute left-2.5 top-1.5 text-slate-400 font-mono">₹</span>
                  <input
                    type="number"
                    step="0.50"
                    min="0"
                    value={settings.amountTolerance}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        amountTolerance: Math.max(0, parseFloat(e.target.value) || 0),
                      })
                    }
                    className="w-full pl-6 pr-2.5 py-1 text-xs bg-white border border-slate-300 rounded font-mono"
                  />
                </div>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.requireGstBreakdownMatch}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        requireGstBreakdownMatch: e.target.checked,
                      })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-slate-800 font-medium">Reconcile CGST, SGST, IGST Separately</span>
                </label>
              </div>

              <div className="flex flex-col justify-center">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.normalizeInvoiceNumbers}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        normalizeInvoiceNumbers: e.target.checked,
                      })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-slate-800 font-medium">Normalize Invoice / Bill # (strip -, /, #)</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* High-Density Reconciliation Data Grid with Indian GST Columns */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-medium">
              <tr>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Invoice #</th>
                <th className="py-2.5 px-3">Supplier & GSTIN</th>
                <th className="py-2.5 px-3">Date</th>
                <th className="py-2.5 px-3 text-right">Invoice Total (₹)</th>
                <th className="py-2.5 px-3 text-right">Invoice GST (₹)</th>
                <th className="py-2.5 px-3 text-right">Ledger Total (₹)</th>
                <th className="py-2.5 px-3 text-right">Ledger GST (₹)</th>
                <th className="py-2.5 px-3 text-right">Variance (₹)</th>
                <th className="py-2.5 px-3">Audit Discrepancy Remarks</th>
                <th className="py-2.5 px-3 text-right">Audit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredItems.map((item) => {
                const inv = item.invoice;
                const led = item.ledger;
                const hasVariance = item.amountVariance !== 0;

                // Format GST breakdown text
                const invoiceGstText = inv
                  ? inv.igst > 0
                    ? `IGST: ${formatINR(inv.igst)}`
                    : `CGST: ${formatINR(inv.cgst)} + SGST: ${formatINR(inv.sgst)}`
                  : '—';

                const ledgerGstText = led
                  ? led.igst > 0
                    ? `IGST: ${formatINR(led.igst)}`
                    : `CGST: ${formatINR(led.cgst)} + SGST: ${formatINR(led.sgst)}`
                  : '—';

                return (
                  <tr
                    key={item.id}
                    onClick={() => onSelectItem(item)}
                    className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                  >
                    {/* Status */}
                    <td className="py-2 px-3 whitespace-nowrap">
                      {renderStatus(item.status)}
                    </td>

                    {/* Invoice # */}
                    <td className="py-2 px-3 whitespace-nowrap font-mono font-semibold text-slate-900">
                      {inv?.invoiceNumber || (led ? `Ledger: ${led.invoiceNumber}` : '—')}
                    </td>

                    {/* Supplier & GSTIN */}
                    <td className="py-2 px-3 whitespace-nowrap max-w-[200px]">
                      <span className="font-medium text-slate-900 block truncate" title={inv?.vendorName || led?.vendorName}>
                        {inv?.vendorName || led?.vendorName || '—'}
                      </span>
                      {(inv?.vendorGstin || led?.vendorGstin) && (
                        <span className="text-[10px] font-mono text-indigo-700 bg-indigo-50 px-1 py-0.2 rounded border border-indigo-100/80">
                          {inv?.vendorGstin || led?.vendorGstin}
                        </span>
                      )}
                    </td>

                    {/* Date */}
                    <td className="py-2 px-3 whitespace-nowrap text-slate-600 font-mono text-[11px]">
                      {inv?.invoiceDate || led?.date || '—'}
                    </td>

                    {/* Extracted Invoice Total */}
                    <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-900 font-bold">
                      {inv ? formatINR(inv.totalAmount) : '—'}
                    </td>

                    {/* Extracted Invoice GST */}
                    <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-700">
                      <div>{inv ? formatINR(inv.taxAmount) : '—'}</div>
                      <div className="text-[10px] text-slate-400">{invoiceGstText}</div>
                    </td>

                    {/* Ledger Amount */}
                    <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums font-semibold text-slate-900">
                      {led ? (
                        formatINR(led.amount)
                      ) : (
                        <span className="text-slate-400 italic font-normal">Not in Ledger</span>
                      )}
                    </td>

                    {/* Ledger GST */}
                    <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums text-slate-600">
                      <div>{led ? formatINR(led.tax) : '—'}</div>
                      <div className="text-[10px] text-slate-400">{ledgerGstText}</div>
                    </td>

                    {/* Amount Variance */}
                    <td className="py-2 px-3 whitespace-nowrap text-right font-mono tabular-nums">
                      {hasVariance ? (
                        <span
                          className={`font-bold ${
                            item.status === 'NOT_IN_LEDGER'
                              ? 'text-slate-600'
                              : item.amountVariance > 0
                              ? 'text-rose-600'
                              : 'text-amber-600'
                          }`}
                        >
                          {item.amountVariance > 0 ? '+' : ''}
                          {formatINR(item.amountVariance)}
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-semibold font-mono">₹0.00</span>
                      )}
                    </td>

                    {/* Discrepancy Remarks */}
                    <td className="py-2 px-3 max-w-[260px]">
                      {item.discrepancies.length > 0 ? (
                        <span className="text-amber-800 text-[11px] truncate block font-medium" title={item.discrepancies.map((d) => d.message).join('; ')}>
                          {item.discrepancies[0].message}
                        </span>
                      ) : (
                        <span className="text-emerald-700 text-[11px] font-medium">Exact Match (No Variance)</span>
                      )}
                    </td>

                    {/* Audit Action */}
                    <td className="py-2 px-3 whitespace-nowrap text-right" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onSelectItem(item)}
                        className="inline-flex items-center gap-1 text-slate-600 hover:text-indigo-600 font-semibold px-2 py-1 rounded hover:bg-slate-100 transition-colors cursor-pointer"
                        title="View side-by-side reconciliation comparison"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Compare</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <span>
            Showing {filteredItems.length} of {items.length} records · Click any row to inspect field-by-field differences & invoice voucher
          </span>

          <div className="flex items-center gap-3">
            <span className="font-mono tabular-nums font-semibold text-slate-700">
              Total Variance: {formatINR(summary.totalDiscrepancyAmount)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
