import React from 'react';
import { UploadCloud, Cpu, FileSpreadsheet, GitCompare, Check } from 'lucide-react';

interface WorkflowTrackerProps {
  invoiceCount: number;
  extractedCount: number;
  ledgerCount: number;
  reconciledCount: number;
  matchedCount: number;
  mismatchedCount: number;
  notInLedgerCount: number;
  activeStep: number;
  onStepClick: (stepIndex: number) => void;
}

export const WorkflowTracker: React.FC<WorkflowTrackerProps> = ({
  invoiceCount,
  extractedCount,
  ledgerCount,
  reconciledCount,
  matchedCount,
  mismatchedCount,
  notInLedgerCount,
  activeStep,
  onStepClick,
}) => {
  const steps = [
    {
      id: 1,
      title: 'Upload Invoice',
      subtitle: 'PDF / Image',
      meta: invoiceCount > 0 ? `${invoiceCount} uploaded` : 'Drop tax bills here',
      icon: UploadCloud,
      completed: invoiceCount > 0,
    },
    {
      id: 2,
      title: 'AI / OCR Model',
      subtitle: 'GST OCR Engine',
      meta: extractedCount > 0 ? `${extractedCount} extracted` : 'Vendor, GSTIN, CGST, SGST, IGST, ₹',
      icon: Cpu,
      completed: extractedCount > 0 && extractedCount === invoiceCount,
    },
    {
      id: 3,
      title: 'Upload Ledger',
      subtitle: 'Excel / Tally (.xlsx)',
      meta: ledgerCount > 0 ? `${ledgerCount} records parsed` : 'Upload purchase register',
      icon: FileSpreadsheet,
      completed: ledgerCount > 0,
    },
    {
      id: 4,
      title: 'Matching Engine',
      subtitle: 'GST Audit & Export',
      meta:
        reconciledCount > 0
          ? `${matchedCount} Matched · ${mismatchedCount} Mismatches · ${notInLedgerCount} Not in Ledger`
          : 'Invoice vs Ledger Comparison',
      icon: GitCompare,
      completed: reconciledCount > 0,
    },
  ];

  return (
    <div className="bg-white border-b border-slate-200 py-2.5 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
          {steps.map((step) => {
            const Icon = step.icon;
            const isActive = activeStep === step.id;

            return (
              <button
                key={step.id}
                onClick={() => onStepClick(step.id)}
                className={`flex items-center gap-2.5 p-2 rounded-lg border text-left transition-all cursor-pointer ${
                  isActive
                    ? 'border-indigo-600 bg-indigo-50/60 shadow-2xs'
                    : step.completed
                    ? 'border-slate-200 bg-slate-50/70 hover:bg-slate-100/80'
                    : 'border-slate-200 bg-white hover:bg-slate-50'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 text-xs font-semibold ${
                    step.completed
                      ? 'bg-emerald-100 text-emerald-800'
                      : isActive
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {step.completed ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Icon className="w-3.5 h-3.5" />}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-900 truncate">
                      {step.id}. {step.title}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">{step.subtitle}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">{step.meta}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
