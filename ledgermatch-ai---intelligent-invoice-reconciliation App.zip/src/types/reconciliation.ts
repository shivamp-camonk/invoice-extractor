/**
 * Data structures for Indian GST Invoice OCR Extraction and Ledger Reconciliation
 * Supports CGST, SGST, IGST breakdown and INR (₹) currency.
 */

export interface LineItem {
  description: string;
  hsnSac?: string;
  quantity?: number;
  unitPrice?: number;
  taxableAmount?: number;
  gstRate?: number; // e.g. 18, 12, 5
  cgst?: number;
  sgst?: number;
  igst?: number;
  amount: number;
}

export interface ExtractedInvoice {
  id: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  fileDataUrl?: string;
  uploadedAt: string;
  status: 'pending' | 'processing' | 'extracted' | 'error';
  errorMessage?: string;
  vendorName: string;
  vendorGstin?: string;
  invoiceNumber: string;
  invoiceDate: string;
  dueDate?: string;
  placeOfSupply?: string; // State / State code
  subtotal: number; // Taxable Value
  cgst: number; // Central GST
  sgst: number; // State GST
  igst: number; // Integrated GST
  taxAmount: number; // Total GST (CGST + SGST + IGST)
  totalAmount: number; // Gross Total Payable
  currency: string; // 'INR' (₹)
  lineItems: LineItem[];
  confidenceScore: number;
  notes?: string;
  isManuallyEdited?: boolean;
}

export interface LedgerRecord {
  id: string;
  rowIndex: number;
  invoiceNumber: string;
  vendorName: string;
  vendorGstin?: string;
  date: string;
  taxableAmount?: number;
  cgst: number;
  sgst: number;
  igst: number;
  tax: number; // Total GST
  amount: number; // Total Invoiced / Ledger Amount
  currency?: string;
  accountCode?: string;
  description?: string;
  rawRow?: Record<string, any>;
}

export interface DiscrepancyDetail {
  field: 'amount' | 'cgst' | 'sgst' | 'igst' | 'tax' | 'vendor' | 'date' | 'gstin';
  fieldLabel: string;
  invoiceVal: string | number;
  ledgerVal: string | number;
  difference?: number;
  message: string;
  severity: 'high' | 'medium' | 'low';
}

export type ReconciliationStatus = 'MATCHED' | 'MISMATCHED' | 'NOT_IN_LEDGER' | 'NOT_IN_INVOICES';

export interface ReconciliationItem {
  id: string;
  status: ReconciliationStatus;
  invoiceId?: string;
  ledgerId?: string;
  matchScore: number; // 0 to 100
  matchMethod: 'exact_invoice_no' | 'fuzzy_invoice_no' | 'vendor_amount' | 'gstin_match' | 'manual' | 'unmatched';
  invoice?: ExtractedInvoice;
  ledger?: LedgerRecord;
  discrepancies: DiscrepancyDetail[];
  amountVariance: number;
  taxVariance: number;
  cgstVariance: number;
  sgstVariance: number;
  igstVariance: number;
  resolved?: boolean;
  resolutionNote?: string;
}

export interface ReconciliationSummary {
  totalInvoices: number;
  totalLedgerRecords: number;
  matchedCount: number;
  mismatchedCount: number;
  notInLedgerCount: number;
  notInInvoicesCount: number;
  totalInvoiceAmount: number;
  totalLedgerAmount: number;
  totalMatchedAmount: number;
  totalDiscrepancyAmount: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  matchRatePercent: number;
}

export interface MatchingSettings {
  amountTolerance: number; // e.g. ₹1.00 or ₹0.10
  fuzzyVendorMatching: boolean;
  normalizeInvoiceNumbers: boolean;
  requireGstBreakdownMatch: boolean; // Compare CGST, SGST, IGST separately
}
