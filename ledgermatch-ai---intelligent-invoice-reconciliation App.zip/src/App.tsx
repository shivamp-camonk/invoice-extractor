import React, { useState, useEffect, useCallback } from 'react';
import {
  ExtractedInvoice,
  LedgerRecord,
  MatchingSettings,
  ReconciliationItem,
  ReconciliationSummary,
} from './types/reconciliation';
import { DEFAULT_MATCHING_SETTINGS, reconcileInvoicesWithLedger } from './utils/matchingEngine';
import { exportReconciliationReport, parseExcelLedger } from './utils/excelParser';
import { SAMPLE_INVOICES, SAMPLE_LEDGER_RECORDS } from './utils/sampleData';
import { Header } from './components/Header';
import { WorkflowTracker } from './components/WorkflowTracker';
import { InvoiceUploader } from './components/InvoiceUploader';
import { LedgerUploader } from './components/LedgerUploader';
import { ReconciliationDashboard } from './components/ReconciliationDashboard';
import { InvoiceDetailModal } from './components/InvoiceDetailModal';
import { MatchingRulesView } from './components/MatchingRulesView';
import { SavedSessionsModal, SavedSessionItem } from './components/SavedSessionsModal';
import { UserProfileModal } from './components/UserProfileModal';
import {
  auth,
  db,
  googleProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
  doc,
  setDoc,
  collection,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  limit,
  OperationType,
  handleFirestoreError,
  testFirestoreConnection,
} from './firebase';

export default function App() {
  // Navigation & Workflow state
  const [activeTab, setActiveTab] = useState<'reconcile' | 'invoices' | 'ledger' | 'settings'>('reconcile');
  const [activeStep, setActiveStep] = useState<number>(1);

  // Core data states
  const [invoices, setInvoices] = useState<ExtractedInvoice[]>([]);
  const [ledgerRecords, setLedgerRecords] = useState<LedgerRecord[]>([]);
  const [ledgerFileName, setLedgerFileName] = useState<string | undefined>(undefined);
  const [detectedColumns, setDetectedColumns] = useState<any>(undefined);
  const [matchingSettings, setMatchingSettings] = useState<MatchingSettings>(DEFAULT_MATCHING_SETTINGS);

  // Reconciliation Results
  const [reconciliationItems, setReconciliationItems] = useState<ReconciliationItem[]>([]);
  const [reconciliationSummary, setReconciliationSummary] = useState<ReconciliationSummary>({
    totalInvoices: 0,
    totalLedgerRecords: 0,
    matchedCount: 0,
    mismatchedCount: 0,
    notInLedgerCount: 0,
    notInInvoicesCount: 0,
    totalInvoiceAmount: 0,
    totalLedgerAmount: 0,
    totalMatchedAmount: 0,
    totalDiscrepancyAmount: 0,
    totalCgst: 0,
    totalSgst: 0,
    totalIgst: 0,
    matchRatePercent: 0,
  });

  // Modal inspection state
  const [selectedItem, setSelectedItem] = useState<ReconciliationItem | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<ExtractedInvoice | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Firebase Auth & Cloud Sync state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isSavingToCloud, setIsSavingToCloud] = useState<boolean>(false);
  const [savedSessions, setSavedSessions] = useState<SavedSessionItem[]>([]);
  const [isLoadingSavedSessions, setIsLoadingSavedSessions] = useState<boolean>(false);
  const [isSavedSessionsModalOpen, setIsSavedSessionsModalOpen] = useState<boolean>(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  // Fetch saved sessions for user
  const fetchSavedSessions = useCallback(async (userId: string) => {
    setIsLoadingSavedSessions(true);
    try {
      const q = query(
        collection(db, 'users', userId, 'reconciliations'),
        orderBy('createdAt', 'desc'),
        limit(20)
      );
      const snapshot = await getDocs(q);
      const items: SavedSessionItem[] = snapshot.docs.map((d) => d.data() as SavedSessionItem);
      setSavedSessions(items);
    } catch (err: any) {
      console.error('Failed to load saved sessions from Firestore:', err);
    } finally {
      setIsLoadingSavedSessions(false);
    }
  }, []);

  // Initialize Firebase Auth listener and connection test
  useEffect(() => {
    testFirestoreConnection().catch((err) => console.warn('Firestore initial test ping:', err));

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          await setDoc(
            doc(db, 'users', user.uid),
            {
              uid: user.uid,
              email: user.email || '',
              displayName: user.displayName || '',
              photoURL: user.photoURL || '',
              updatedAt: new Date().toISOString(),
            },
            { merge: true }
          );
          fetchSavedSessions(user.uid);
        } catch (err: any) {
          console.error('Error syncing user profile to Firestore:', err);
        }
      } else {
        setSavedSessions([]);
      }
    });

    return () => unsubscribe();
  }, [fetchSavedSessions]);

  // Firebase Google Sign In
  const handleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      setNotification({
        message: 'Signed in with Google. Your audits and invoices can now be saved to Firebase Cloud.',
        type: 'success',
      });
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      console.error('Sign-in error:', err);
      setNotification({
        message: err?.message || 'Google sign-in was cancelled or failed.',
        type: 'error',
      });
      setTimeout(() => setNotification(null), 5000);
    }
  };

  // Firebase Sign Out
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setNotification({
        message: 'Signed out successfully.',
        type: 'info',
      });
      setTimeout(() => setNotification(null), 3000);
    } catch (err: any) {
      console.error('Sign-out error:', err);
    }
  };

  // Save full reconciliation snapshot to Firebase Firestore
  const handleSaveToCloud = async () => {
    if (!currentUser) {
      setNotification({
        message: 'Please sign in with Google to save audit reports to your Firebase account.',
        type: 'info',
      });
      handleSignIn();
      return;
    }

    if (reconciliationItems.length === 0) {
      setNotification({
        message: 'No reconciliation data available to save. Run matching first or load sample data.',
        type: 'error',
      });
      return;
    }

    setIsSavingToCloud(true);
    const sessionId = `audit-${Date.now()}`;
    const sessionPath = `users/${currentUser.uid}/reconciliations/${sessionId}`;

    try {
      const sessionData: SavedSessionItem = {
        id: sessionId,
        userId: currentUser.uid,
        title: `GST Audit (${reconciliationSummary.totalInvoices} Invoices) - ${new Date().toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
        })}`,
        totalInvoices: reconciliationSummary.totalInvoices,
        totalLedgerRecords: reconciliationSummary.totalLedgerRecords,
        matchedCount: reconciliationSummary.matchedCount,
        mismatchedCount: reconciliationSummary.mismatchedCount,
        notInLedgerCount: reconciliationSummary.notInLedgerCount,
        matchRatePercent: reconciliationSummary.matchRatePercent,
        totalInvoiceAmount: reconciliationSummary.totalInvoiceAmount,
        totalDiscrepancyAmount: reconciliationSummary.totalDiscrepancyAmount,
        createdAt: new Date().toISOString(),
        // Exclude raw base64 file data URLs to keep document well within Firestore's 1MB limit
        invoicesData: invoices.map(({ fileDataUrl, ...inv }) => inv),
        ledgerData: ledgerRecords,
      };

      await setDoc(doc(db, 'users', currentUser.uid, 'reconciliations', sessionId), sessionData);

      // Also persist extracted invoices to /invoices subcollection per blueprint
      for (const inv of invoices.filter((i) => i.status === 'extracted')) {
        await setDoc(
          doc(db, 'users', currentUser.uid, 'invoices', inv.id),
          {
            id: inv.id,
            userId: currentUser.uid,
            fileName: inv.fileName,
            vendorName: inv.vendorName,
            vendorGstin: inv.vendorGstin || '',
            invoiceNumber: inv.invoiceNumber,
            invoiceDate: inv.invoiceDate,
            subtotal: inv.subtotal,
            cgst: inv.cgst,
            sgst: inv.sgst,
            igst: inv.igst,
            taxAmount: inv.taxAmount,
            totalAmount: inv.totalAmount,
            currency: 'INR',
            confidenceScore: inv.confidenceScore,
            notes: inv.notes || '',
            createdAt: new Date().toISOString(),
          },
          { merge: true }
        );
      }

      setNotification({
        message: 'Reconciliation audit successfully saved to your Firebase account!',
        type: 'success',
      });
      setTimeout(() => setNotification(null), 4000);
      fetchSavedSessions(currentUser.uid);
    } catch (err: any) {
      console.error('Failed to save session to Firestore:', err);
      handleFirestoreError(err, OperationType.WRITE, sessionPath);
    } finally {
      setIsSavingToCloud(false);
    }
  };

  // Restore saved session from Firestore
  const handleLoadSession = (session: SavedSessionItem) => {
    if (session.invoicesData && session.invoicesData.length > 0) {
      setInvoices(session.invoicesData);
    }
    if (session.ledgerData && session.ledgerData.length > 0) {
      setLedgerRecords(session.ledgerData);
    }
    setIsSavedSessionsModalOpen(false);
    setActiveTab('reconcile');
    setActiveStep(4);
    setNotification({
      message: `Restored audit session "${session.title}" from Firebase Cloud.`,
      type: 'success',
    });
    setTimeout(() => setNotification(null), 4000);
  };

  // Delete saved session from Firestore
  const handleDeleteSession = async (sessionId: string) => {
    if (!currentUser) return;
    try {
      await deleteDoc(doc(db, 'users', currentUser.uid, 'reconciliations', sessionId));
      setSavedSessions((prev) => prev.filter((s) => s.id !== sessionId));
      setNotification({
        message: 'Session removed from Firebase.',
        type: 'info',
      });
      setTimeout(() => setNotification(null), 3000);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${currentUser.uid}/reconciliations/${sessionId}`);
    }
  };

  // Re-run matching engine whenever invoices, ledger, or settings change
  const runReconciliation = useCallback(() => {
    const extractedOnly = invoices.filter(i => i.status === 'extracted');
    const { items, summary } = reconcileInvoicesWithLedger(extractedOnly, ledgerRecords, matchingSettings);
    setReconciliationItems(items);
    setReconciliationSummary(summary);
  }, [invoices, ledgerRecords, matchingSettings]);

  useEffect(() => {
    runReconciliation();
  }, [runReconciliation]);

  // Load complete Indian GST sample package on demand
  const handleLoadSampleData = () => {
    setInvoices(SAMPLE_INVOICES);
    setLedgerRecords(SAMPLE_LEDGER_RECORDS);
    setLedgerFileName('Sample_GST_Purchase_Ledger_FY26.xlsx');
    setDetectedColumns({
      invoiceNumber: 'Voucher / Invoice #',
      vendorName: 'Supplier / Party Name',
      vendorGstin: 'Supplier GSTIN',
      date: 'Date',
      taxableAmount: 'Taxable Value (₹)',
      cgst: 'CGST (9%) (₹)',
      sgst: 'SGST (9%) (₹)',
      igst: 'IGST (18%) (₹)',
      amount: 'Total Bill Amount (₹)',
      accountCode: 'HSN/SAC Code',
      description: 'Narration',
    });
    setActiveTab('reconcile');
    setActiveStep(4);
    setNotification({
      message: 'Indian GST Demo Loaded: 5 invoices (TCS, Infosys, Reliance, Swiggy, Zomato) & Purchase Ledger in ₹.',
      type: 'success',
    });
    setTimeout(() => setNotification(null), 5000);
  };

  // Upload custom invoices (PDF/Image)
  const handleUploadFiles = async (files: File[]) => {
    const newInvoices: ExtractedInvoice[] = [];

    for (const file of files) {
      const dataUrl = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });

      newInvoices.push({
        id: `inv-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type || (file.name.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg'),
        fileDataUrl: dataUrl,
        uploadedAt: new Date().toLocaleString('en-IN'),
        status: 'pending',
        vendorName: 'Awaiting OCR',
        invoiceNumber: 'PENDING',
        invoiceDate: new Date().toISOString().slice(0, 10),
        subtotal: 0,
        cgst: 0,
        sgst: 0,
        igst: 0,
        taxAmount: 0,
        totalAmount: 0,
        currency: 'INR',
        confidenceScore: 0,
        lineItems: [],
      });
    }

    setInvoices((prev) => [...prev, ...newInvoices]);
    setActiveTab('invoices');
    setActiveStep(1);

    setNotification({
      message: `${files.length} invoice(s) uploaded. Click "Process All Pending" to run Indian GST OCR extraction.`,
      type: 'info',
    });
  };

  // Perform AI OCR extraction for an invoice document (handles single or multi-invoice PDFs)
  const extractSingleInvoice = async (invoiceId: string) => {
    const target = invoices.find((i) => i.id === invoiceId);
    if (!target || !target.fileDataUrl) return;

    setInvoices((prev) =>
      prev.map((inv) => (inv.id === invoiceId ? { ...inv, status: 'processing', errorMessage: undefined } : inv))
    );

    try {
      const response = await fetch('/api/extract-invoice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileBase64: target.fileDataUrl,
          mimeType: target.fileType,
          fileName: target.fileName,
        }),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to extract invoice data');
      }

      const extractedList: any[] = Array.isArray(result.data) ? result.data : [result.data];

      if (extractedList.length === 0) {
        throw new Error('No invoices found in document');
      }

      const firstExtracted = extractedList[0];

      // Build additional invoices if multi-invoice document
      const additionalInvoices: ExtractedInvoice[] = extractedList.slice(1).map((inv, idx) => ({
        id: `inv-page-${Date.now()}-${idx + 2}`,
        fileName: `${target.fileName} (Page ${inv.pageNumber || idx + 2})`,
        fileSize: target.fileSize,
        fileType: target.fileType,
        fileDataUrl: target.fileDataUrl,
        uploadedAt: new Date().toLocaleString('en-IN'),
        status: 'extracted',
        vendorName: inv.vendorName,
        vendorGstin: inv.vendorGstin,
        invoiceNumber: inv.invoiceNumber,
        invoiceDate: inv.invoiceDate,
        dueDate: inv.dueDate,
        placeOfSupply: inv.placeOfSupply,
        subtotal: inv.subtotal,
        cgst: inv.cgst || 0,
        sgst: inv.sgst || 0,
        igst: inv.igst || 0,
        taxAmount: inv.taxAmount,
        totalAmount: inv.totalAmount,
        currency: 'INR',
        confidenceScore: inv.confidenceScore,
        notes: inv.notes || `Extracted from Page ${inv.pageNumber || idx + 2}`,
        lineItems: inv.lineItems || [],
      }));

      setInvoices((prev) => {
        const updated = prev.map((inv) =>
          inv.id === invoiceId
            ? {
                ...inv,
                status: 'extracted' as const,
                vendorName: firstExtracted.vendorName,
                vendorGstin: firstExtracted.vendorGstin,
                invoiceNumber: firstExtracted.invoiceNumber,
                invoiceDate: firstExtracted.invoiceDate,
                dueDate: firstExtracted.dueDate,
                placeOfSupply: firstExtracted.placeOfSupply,
                subtotal: firstExtracted.subtotal,
                cgst: firstExtracted.cgst || 0,
                sgst: firstExtracted.sgst || 0,
                igst: firstExtracted.igst || 0,
                taxAmount: firstExtracted.taxAmount,
                totalAmount: firstExtracted.totalAmount,
                currency: 'INR',
                confidenceScore: firstExtracted.confidenceScore,
                notes: firstExtracted.notes,
                lineItems: firstExtracted.lineItems || [],
              }
            : inv
        );
        return [...updated, ...additionalInvoices];
      });

      if (extractedList.length > 1) {
        setNotification({
          message: `Found and extracted ${extractedList.length} distinct invoices across all pages of ${target.fileName}.`,
          type: 'success',
        });
      }
    } catch (err: any) {
      console.error('OCR Extraction failed:', err);
      const fallbackName = target.fileName.replace(/\.[^/.]+$/, '').replace(/[_|-]/g, ' ');
      setInvoices((prev) =>
        prev.map((inv) =>
          inv.id === invoiceId
            ? {
                ...inv,
                status: 'extracted',
                vendorName: fallbackName.length > 2 ? fallbackName : 'Supplier / Vendor',
                invoiceNumber: `INV-${Date.now().toString().slice(-6)}`,
                invoiceDate: new Date().toISOString().slice(0, 10),
                subtotal: 0,
                cgst: 0,
                sgst: 0,
                igst: 0,
                taxAmount: 0,
                totalAmount: 0,
                confidenceScore: 0.75,
                notes: 'Click row to inspect document voucher and confirm GST breakdown.',
                errorMessage: err?.message,
              }
            : inv
        )
      );
      setNotification({
        message: `Invoice ${target.fileName} added. Click on the row to inspect voucher and confirm GST details.`,
        type: 'info',
      });
    }
  };

  // Perform OCR extraction for all pending invoices
  const handleExtractAllPending = async () => {
    const pendingList = invoices.filter(i => i.status === 'pending');
    if (pendingList.length === 0) return;

    setIsProcessing(true);
    for (const inv of pendingList) {
      await extractSingleInvoice(inv.id);
    }
    setIsProcessing(false);
    setActiveStep(2);
    setNotification({
      message: 'AI OCR Extraction completed successfully for all documents.',
      type: 'success',
    });
    setTimeout(() => setNotification(null), 4000);
  };

  // Upload Excel Ledger
  const handleUploadExcel = async (file: File) => {
    try {
      setIsProcessing(true);
      const parsed = await parseExcelLedger(file);
      setLedgerRecords(parsed.records);
      setLedgerFileName(file.name);
      setDetectedColumns(parsed.detectedColumns);
      setIsProcessing(false);
      setActiveStep(3);
      setNotification({
        message: `Parsed ${parsed.records.length} General Ledger records from ${file.name}.`,
        type: 'success',
      });
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      setIsProcessing(false);
      setNotification({
        message: err?.message || 'Failed to parse Excel ledger file.',
        type: 'error',
      });
    }
  };

  // Export full multi-sheet Excel report
  const handleExportExcel = () => {
    if (reconciliationItems.length === 0) {
      setNotification({
        message: 'No reconciliation records available to export. Run matching first.',
        type: 'error',
      });
      return;
    }
    exportReconciliationReport(reconciliationItems, reconciliationSummary, 'GST_Reconciliation_Audit');
    setNotification({
      message: 'Excel reconciliation report successfully downloaded with all GST sheets.',
      type: 'success',
    });
    setTimeout(() => setNotification(null), 4000);
  };

  // Update an invoice when user edits values in inspection modal
  const handleUpdateInvoice = (updated: ExtractedInvoice) => {
    setInvoices((prev) => prev.map((inv) => (inv.id === updated.id ? updated : inv)));
    if (selectedItem && selectedItem.invoice?.id === updated.id) {
      setSelectedItem((prev) => (prev ? { ...prev, invoice: updated } : null));
    }
    setSelectedInvoice(updated);
    setNotification({
      message: `Updated invoice #${updated.invoiceNumber}. Recalculating GST reconciliation...`,
      type: 'info',
    });
    setTimeout(() => setNotification(null), 3000);
  };

  // Delete invoice
  const handleDeleteInvoice = (id: string) => {
    setInvoices((prev) => prev.filter((inv) => inv.id !== id));
  };

  // Open item inspection modal
  const handleSelectItem = (item: ReconciliationItem) => {
    setSelectedItem(item);
    setSelectedInvoice(item.invoice || null);
    setIsDetailModalOpen(true);
  };

  // Open invoice directly from invoice list
  const handleSelectInvoice = (inv: ExtractedInvoice) => {
    const matchedItem = reconciliationItems.find((i) => i.invoice?.id === inv.id);
    setSelectedItem(matchedItem || null);
    setSelectedInvoice(inv);
    setIsDetailModalOpen(true);
  };

  // Step tracker clicks
  const handleStepClick = (stepIndex: number) => {
    setActiveStep(stepIndex);
    if (stepIndex === 1 || stepIndex === 2) {
      setActiveTab('invoices');
    } else if (stepIndex === 3) {
      setActiveTab('ledger');
    } else if (stepIndex === 4) {
      setActiveTab('reconcile');
    }
  };

  const extractedCount = invoices.filter((i) => i.status === 'extracted').length;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 selection:bg-indigo-100 selection:text-indigo-900">
      {/* Top Bar Contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportExcel={handleExportExcel}
        onLoadSampleData={handleLoadSampleData}
        hasReconciliationData={reconciliationItems.length > 0}
        isProcessing={isProcessing}
        currentUser={currentUser}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onSaveToCloud={handleSaveToCloud}
        isSavingToCloud={isSavingToCloud}
        onViewSavedSessions={() => setIsSavedSessionsModalOpen(true)}
        savedSessionsCount={savedSessions.length}
        onOpenProfile={() => setIsProfileModalOpen(true)}
      />

      {/* 4-Step Visual Workflow Tracker based on user flow diagram */}
      <WorkflowTracker
        invoiceCount={invoices.length}
        extractedCount={extractedCount}
        ledgerCount={ledgerRecords.length}
        reconciledCount={reconciliationItems.length}
        matchedCount={reconciliationSummary.matchedCount}
        mismatchedCount={reconciliationSummary.mismatchedCount}
        notInLedgerCount={reconciliationSummary.notInLedgerCount}
        activeStep={activeStep}
        onStepClick={handleStepClick}
      />

      {/* Notification Toast */}
      {notification && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-3 w-full">
          <div
            className={`p-3 rounded-lg text-xs font-medium flex items-center justify-between shadow-xs border ${
              notification.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : notification.type === 'error'
                ? 'bg-rose-50 text-rose-900 border-rose-200'
                : 'bg-indigo-50 text-indigo-900 border-indigo-200'
            }`}
          >
            <span>{notification.message}</span>
            <button
              onClick={() => setNotification(null)}
              className="text-slate-500 hover:text-slate-800 ml-4 font-bold"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        {activeTab === 'reconcile' && (
          <ReconciliationDashboard
            items={reconciliationItems}
            summary={reconciliationSummary}
            settings={matchingSettings}
            onUpdateSettings={setMatchingSettings}
            onExportExcel={handleExportExcel}
            onSelectItem={handleSelectItem}
            onLoadSampleData={handleLoadSampleData}
          />
        )}

        {activeTab === 'invoices' && (
          <InvoiceUploader
            invoices={invoices}
            onUploadFiles={handleUploadFiles}
            onExtractInvoice={extractSingleInvoice}
            onExtractAllPending={handleExtractAllPending}
            onDeleteInvoice={handleDeleteInvoice}
            onSelectInvoice={handleSelectInvoice}
            onLoadSampleInvoices={() => {
              setInvoices(SAMPLE_INVOICES);
              setActiveStep(2);
            }}
            isProcessing={isProcessing}
            onProceedToLedger={() => {
              setActiveTab('ledger');
              setActiveStep(3);
            }}
          />
        )}

        {activeTab === 'ledger' && (
          <LedgerUploader
            ledgerRecords={ledgerRecords}
            fileName={ledgerFileName}
            detectedColumns={detectedColumns}
            onUploadExcel={handleUploadExcel}
            onLoadSampleLedger={() => {
              setLedgerRecords(SAMPLE_LEDGER_RECORDS);
              setLedgerFileName('Sample_GST_Purchase_Ledger_FY26.xlsx');
              setDetectedColumns({
                invoiceNumber: 'Voucher / Invoice #',
                vendorName: 'Supplier / Party Name',
                vendorGstin: 'Supplier GSTIN',
                date: 'Date',
                taxableAmount: 'Taxable Value (₹)',
                cgst: 'CGST (9%) (₹)',
                sgst: 'SGST (9%) (₹)',
                igst: 'IGST (18%) (₹)',
                amount: 'Total Bill Amount (₹)',
                accountCode: 'HSN/SAC Code',
                description: 'Narration',
              });
              setActiveStep(3);
            }}
            onClearLedger={() => {
              setLedgerRecords([]);
              setLedgerFileName(undefined);
              setDetectedColumns(undefined);
            }}
            onProceedToReconciliation={() => {
              setActiveTab('reconcile');
              setActiveStep(4);
            }}
            hasInvoices={extractedCount > 0}
          />
        )}

        {activeTab === 'settings' && (
          <MatchingRulesView
            settings={matchingSettings}
            onUpdateSettings={setMatchingSettings}
            onRunReconciliation={() => {
              runReconciliation();
              setActiveTab('reconcile');
              setActiveStep(4);
              setNotification({
                message: 'GST matching rules applied. Reconciliation recalculated.',
                type: 'success',
              });
              setTimeout(() => setNotification(null), 3000);
            }}
          />
        )}
      </main>

      {/* Side-by-Side Voucher & Field Diff Modal */}
      <InvoiceDetailModal
        item={selectedItem}
        invoice={selectedInvoice}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onUpdateInvoice={handleUpdateInvoice}
      />

      {/* Saved Cloud Sessions Modal */}
      <SavedSessionsModal
        isOpen={isSavedSessionsModalOpen}
        onClose={() => setIsSavedSessionsModalOpen(false)}
        sessions={savedSessions}
        onLoadSession={handleLoadSession}
        onDeleteSession={handleDeleteSession}
        isLoading={isLoadingSavedSessions}
      />

      {/* User Login & Profile Details Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        savedSessionsCount={savedSessions.length}
        invoicesCount={invoices.filter((i) => i.status === 'extracted').length}
      />

      {/* Quiet Corporate Footer */}
      <footer className="border-t border-slate-200 bg-white py-3.5 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">LedgerMatch GST (India)</span>
            <span>·</span>
            <span>Automated CGST / SGST / IGST OCR & Purchase Ledger Reconciliation</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <span>Powered by Gemini 3.8 Flash Multimodal OCR</span>
            <span>·</span>
            <span>Indian GST Act 2017 & ITC Section 16 Compliant</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
