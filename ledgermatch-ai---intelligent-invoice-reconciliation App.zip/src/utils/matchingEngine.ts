import {
  DiscrepancyDetail,
  ExtractedInvoice,
  LedgerRecord,
  MatchingSettings,
  ReconciliationItem,
  ReconciliationSummary,
} from '../types/reconciliation';

export const DEFAULT_MATCHING_SETTINGS: MatchingSettings = {
  amountTolerance: 1.0, // ₹1.00 standard Indian currency rounding
  fuzzyVendorMatching: true,
  normalizeInvoiceNumbers: true,
  requireGstBreakdownMatch: true,
};

/**
 * Format numbers according to Indian Rupee (INR) numbering system (Lakhs and Crores)
 * e.g. ₹1,45,000.00
 */
export function formatINR(val: number): string {
  if (val === undefined || val === null || isNaN(val)) return '₹0.00';
  return '₹' + Number(val).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

/**
 * Clean invoice number for robust matching (removes prefixes, symbols, spaces)
 */
export function normalizeInvoiceNum(raw: string): string {
  if (!raw) return '';
  return String(raw)
    .toUpperCase()
    .replace(/^(INV|BILL|GST|VOUCHER|REF|DOC)[-_#\s/]*/i, '')
    .replace(/[^A-Z0-9]/g, '')
    .trim();
}

/**
 * Tokenize and compare vendor names with string overlap
 */
export function calculateVendorSimilarity(nameA: string, nameB: string): number {
  if (!nameA || !nameB) return 0;
  const cleanA = nameA.toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();
  const cleanB = nameB.toLowerCase().replace(/[^a-z0-9\s]/g, '').trim();

  if (cleanA === cleanB) return 1.0;
  if (cleanA.includes(cleanB) || cleanB.includes(cleanA)) return 0.85;

  const stopWords = new Set(['pvt', 'private', 'ltd', 'limited', 'enterprises', 'solutions', 'technologies', 'india', 'corp', 'services']);
  const tokensA = cleanA.split(/\s+/).filter(t => t.length > 1 && !stopWords.has(t));
  const tokensB = cleanB.split(/\s+/).filter(t => t.length > 1 && !stopWords.has(t));

  if (tokensA.length === 0 || tokensB.length === 0) return 0;

  const matches = tokensA.filter(t => tokensB.includes(t));
  const maxTokens = Math.max(tokensA.length, tokensB.length);
  return matches.length / maxTokens;
}

/**
 * Indian GST Reconciliation Engine
 * Evaluates invoices against ledger records comparing:
 * - Gross Total Amount (₹)
 * - CGST, SGST, IGST breakdown (₹)
 * - Vendor GSTIN & Name
 */
export function reconcileInvoicesWithLedger(
  invoices: ExtractedInvoice[],
  ledgerRecords: LedgerRecord[],
  settings: MatchingSettings = DEFAULT_MATCHING_SETTINGS
): {
  items: ReconciliationItem[];
  summary: ReconciliationSummary;
} {
  const items: ReconciliationItem[] = [];
  const matchedLedgerIds = new Set<string>();

  // Compare each extracted invoice
  for (const invoice of invoices) {
    let matchedLedger: LedgerRecord | undefined;
    let matchMethod: ReconciliationItem['matchMethod'] = 'unmatched';
    let matchScore = 0;

    const normInvNumber = normalizeInvoiceNum(invoice.invoiceNumber);

    // 1. Exact Invoice Number match
    matchedLedger = ledgerRecords.find(record => {
      if (matchedLedgerIds.has(record.id)) return false;
      return record.invoiceNumber.trim().toLowerCase() === invoice.invoiceNumber.trim().toLowerCase();
    });

    if (matchedLedger) {
      matchMethod = 'exact_invoice_no';
      matchScore = 98;
    }

    // 2. Normalized Invoice Number match (e.g. GST/2026/01 vs 202601)
    if (!matchedLedger && settings.normalizeInvoiceNumbers && normInvNumber) {
      matchedLedger = ledgerRecords.find(record => {
        if (matchedLedgerIds.has(record.id)) return false;
        const normLedgerNum = normalizeInvoiceNum(record.invoiceNumber);
        return normLedgerNum && normLedgerNum === normInvNumber;
      });

      if (matchedLedger) {
        matchMethod = 'fuzzy_invoice_no';
        matchScore = 90;
      }
    }

    // 3. Match by GSTIN + Amount within tolerance
    if (!matchedLedger && invoice.vendorGstin) {
      matchedLedger = ledgerRecords.find(record => {
        if (matchedLedgerIds.has(record.id)) return false;
        const gstinMatch = record.vendorGstin && record.vendorGstin.trim().toUpperCase() === invoice.vendorGstin?.trim().toUpperCase();
        const amountDiff = Math.abs(invoice.totalAmount - record.amount);
        return gstinMatch && amountDiff <= settings.amountTolerance;
      });

      if (matchedLedger) {
        matchMethod = 'gstin_match';
        matchScore = 92;
      }
    }

    // 4. Fallback: Match by Vendor Name similarity + Total Amount within tolerance
    if (!matchedLedger && settings.fuzzyVendorMatching) {
      for (const record of ledgerRecords) {
        if (matchedLedgerIds.has(record.id)) continue;

        const amountDiff = Math.abs(invoice.totalAmount - record.amount);
        const vendorSim = calculateVendorSimilarity(invoice.vendorName, record.vendorName);

        if (amountDiff <= settings.amountTolerance && vendorSim >= 0.6) {
          matchedLedger = record;
          matchMethod = 'vendor_amount';
          matchScore = Math.round(vendorSim * 90);
          break;
        }
      }
    }

    // If still not matched, check if normalized invoice number matches with a differing amount
    if (!matchedLedger) {
      matchedLedger = ledgerRecords.find(record => {
        if (matchedLedgerIds.has(record.id)) return false;
        const normLedgerNum = normalizeInvoiceNum(record.invoiceNumber);
        return normLedgerNum && normInvNumber && normLedgerNum === normInvNumber;
      });

      if (matchedLedger) {
        matchMethod = 'fuzzy_invoice_no';
        matchScore = 75;
      }
    }

    // Assign Status and Discrepancies
    if (!matchedLedger) {
      // Not in Ledger
      items.push({
        id: `recon-inv-${invoice.id}`,
        status: 'NOT_IN_LEDGER',
        invoiceId: invoice.id,
        matchScore: 0,
        matchMethod: 'unmatched',
        invoice,
        ledger: undefined,
        discrepancies: [
          {
            field: 'amount',
            fieldLabel: 'Ledger Record',
            invoiceVal: invoice.totalAmount,
            ledgerVal: 'Not found in Books',
            message: `Invoice #${invoice.invoiceNumber} (${formatINR(invoice.totalAmount)}) has no entry in General Ledger / Tally books.`,
            severity: 'high',
          },
        ],
        amountVariance: invoice.totalAmount,
        taxVariance: invoice.taxAmount,
        cgstVariance: invoice.cgst,
        sgstVariance: invoice.sgst,
        igstVariance: invoice.igst,
      });
    } else {
      matchedLedgerIds.add(matchedLedger.id);
      const discrepancies: DiscrepancyDetail[] = [];

      // Total Gross Amount Mismatch
      const amountDiff = invoice.totalAmount - matchedLedger.amount;
      const isAmountMismatch = Math.abs(amountDiff) > settings.amountTolerance;

      if (isAmountMismatch) {
        discrepancies.push({
          field: 'amount',
          fieldLabel: 'Total Invoice Amount',
          invoiceVal: invoice.totalAmount,
          ledgerVal: matchedLedger.amount,
          difference: amountDiff,
          message: `Total Amount mismatch: Invoice is ${formatINR(invoice.totalAmount)} vs Ledger is ${formatINR(matchedLedger.amount)} (Diff: ${amountDiff > 0 ? '+' : ''}${formatINR(amountDiff)})`,
          severity: 'high',
        });
      }

      // CGST Mismatch
      const cgstDiff = invoice.cgst - (matchedLedger.cgst || 0);
      if (settings.requireGstBreakdownMatch && Math.abs(cgstDiff) > settings.amountTolerance && (invoice.cgst > 0 || (matchedLedger.cgst || 0) > 0)) {
        discrepancies.push({
          field: 'cgst',
          fieldLabel: 'CGST',
          invoiceVal: invoice.cgst,
          ledgerVal: matchedLedger.cgst || 0,
          difference: cgstDiff,
          message: `CGST mismatch: Invoice CGST is ${formatINR(invoice.cgst)} vs Ledger CGST ${formatINR(matchedLedger.cgst || 0)}`,
          severity: 'medium',
        });
      }

      // SGST Mismatch
      const sgstDiff = invoice.sgst - (matchedLedger.sgst || 0);
      if (settings.requireGstBreakdownMatch && Math.abs(sgstDiff) > settings.amountTolerance && (invoice.sgst > 0 || (matchedLedger.sgst || 0) > 0)) {
        discrepancies.push({
          field: 'sgst',
          fieldLabel: 'SGST',
          invoiceVal: invoice.sgst,
          ledgerVal: matchedLedger.sgst || 0,
          difference: sgstDiff,
          message: `SGST mismatch: Invoice SGST is ${formatINR(invoice.sgst)} vs Ledger SGST ${formatINR(matchedLedger.sgst || 0)}`,
          severity: 'medium',
        });
      }

      // IGST Mismatch
      const igstDiff = invoice.igst - (matchedLedger.igst || 0);
      if (settings.requireGstBreakdownMatch && Math.abs(igstDiff) > settings.amountTolerance && (invoice.igst > 0 || (matchedLedger.igst || 0) > 0)) {
        discrepancies.push({
          field: 'igst',
          fieldLabel: 'IGST',
          invoiceVal: invoice.igst,
          ledgerVal: matchedLedger.igst || 0,
          difference: igstDiff,
          message: `IGST mismatch: Invoice IGST is ${formatINR(invoice.igst)} vs Ledger IGST ${formatINR(matchedLedger.igst || 0)}`,
          severity: 'medium',
        });
      }

      // Vendor GSTIN Mismatch
      if (invoice.vendorGstin && matchedLedger.vendorGstin) {
        if (invoice.vendorGstin.trim().toUpperCase() !== matchedLedger.vendorGstin.trim().toUpperCase()) {
          discrepancies.push({
            field: 'gstin',
            fieldLabel: 'GSTIN',
            invoiceVal: invoice.vendorGstin,
            ledgerVal: matchedLedger.vendorGstin,
            message: `GSTIN mismatch: Invoice has "${invoice.vendorGstin}" vs Ledger has "${matchedLedger.vendorGstin}"`,
            severity: 'high',
          });
        }
      }

      // Vendor Name Divergence
      const vendorSim = calculateVendorSimilarity(invoice.vendorName, matchedLedger.vendorName);
      if (vendorSim < 0.5) {
        discrepancies.push({
          field: 'vendor',
          fieldLabel: 'Vendor Name',
          invoiceVal: invoice.vendorName,
          ledgerVal: matchedLedger.vendorName,
          message: `Vendor Name mismatch: Extracted "${invoice.vendorName}" differs from Ledger "${matchedLedger.vendorName}"`,
          severity: 'low',
        });
      }

      const status: ReconciliationItem['status'] = discrepancies.length > 0 ? 'MISMATCHED' : 'MATCHED';

      items.push({
        id: `recon-${invoice.id}-${matchedLedger.id}`,
        status,
        invoiceId: invoice.id,
        ledgerId: matchedLedger.id,
        matchScore: status === 'MATCHED' ? matchScore : Math.max(30, matchScore - 20),
        matchMethod,
        invoice,
        ledger: matchedLedger,
        discrepancies,
        amountVariance: amountDiff,
        taxVariance: invoice.taxAmount - matchedLedger.tax,
        cgstVariance: cgstDiff,
        sgstVariance: sgstDiff,
        igstVariance: igstDiff,
      });
    }
  }

  // Ledger records with no matching invoice uploaded
  for (const ledger of ledgerRecords) {
    if (!matchedLedgerIds.has(ledger.id)) {
      items.push({
        id: `recon-ledger-only-${ledger.id}`,
        status: 'NOT_IN_INVOICES',
        ledgerId: ledger.id,
        matchScore: 0,
        matchMethod: 'unmatched',
        invoice: undefined,
        ledger,
        discrepancies: [
          {
            field: 'amount',
            fieldLabel: 'Missing Source Invoice',
            invoiceVal: 'No Invoice Uploaded',
            ledgerVal: ledger.amount,
            message: `Ledger has entry for ${ledger.vendorName} (Ref #${ledger.invoiceNumber}, ${formatINR(ledger.amount)}), but no invoice was uploaded.`,
            severity: 'medium',
          },
        ],
        amountVariance: -ledger.amount,
        taxVariance: -ledger.tax,
        cgstVariance: -ledger.cgst,
        sgstVariance: -ledger.sgst,
        igstVariance: -ledger.igst,
      });
    }
  }

  // Calculate metrics
  const matchedItems = items.filter(i => i.status === 'MATCHED');
  const mismatchedItems = items.filter(i => i.status === 'MISMATCHED');
  const notInLedgerItems = items.filter(i => i.status === 'NOT_IN_LEDGER');
  const notInInvoicesItems = items.filter(i => i.status === 'NOT_IN_INVOICES');

  const totalInvoiceAmount = invoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
  const totalLedgerAmount = ledgerRecords.reduce((sum, led) => sum + led.amount, 0);
  const totalMatchedAmount = matchedItems.reduce((sum, i) => sum + (i.invoice?.totalAmount || 0), 0);
  const totalDiscrepancyAmount = mismatchedItems.reduce((sum, i) => sum + Math.abs(i.amountVariance), 0);

  const totalCgst = invoices.reduce((sum, inv) => sum + inv.cgst, 0);
  const totalSgst = invoices.reduce((sum, inv) => sum + inv.sgst, 0);
  const totalIgst = invoices.reduce((sum, inv) => sum + inv.igst, 0);

  const comparedCount = invoices.length;
  const matchRatePercent = comparedCount > 0 ? (matchedItems.length / comparedCount) * 100 : 0;

  const summary: ReconciliationSummary = {
    totalInvoices: invoices.length,
    totalLedgerRecords: ledgerRecords.length,
    matchedCount: matchedItems.length,
    mismatchedCount: mismatchedItems.length,
    notInLedgerCount: notInLedgerItems.length,
    notInInvoicesCount: notInInvoicesItems.length,
    totalInvoiceAmount,
    totalLedgerAmount,
    totalMatchedAmount,
    totalDiscrepancyAmount,
    totalCgst,
    totalSgst,
    totalIgst,
    matchRatePercent,
  };

  return { items, summary };
}
