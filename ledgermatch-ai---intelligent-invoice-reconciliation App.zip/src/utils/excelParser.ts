import * as XLSX from 'xlsx';
import { ExtractedInvoice, LedgerRecord, ReconciliationItem, ReconciliationSummary } from '../types/reconciliation';
import { formatINR } from './matchingEngine';

/**
 * Intelligent Excel / CSV parser for Indian Financial Ledgers (Tally, Zoho Books, SAP, Marg, Busy)
 */
export interface ParseLedgerResult {
  records: LedgerRecord[];
  detectedColumns: {
    invoiceNumber: string;
    vendorName: string;
    vendorGstin?: string;
    date: string;
    taxableAmount?: string;
    cgst?: string;
    sgst?: string;
    igst?: string;
    tax?: string;
    amount: string;
    description?: string;
    accountCode?: string;
  };
  totalRows: number;
}

// Indian accounting column variations (Tally, Zoho, Marg, ClearTax)
const HEADER_PATTERNS = {
  invoiceNumber: ['invoice_no', 'invoice_number', 'inv_no', 'bill_no', 'voucher_no', 'ref_no', 'doc_num', 'invoice', 'inv', 'bill'],
  vendorName: ['vendor_name', 'party_name', 'supplier_name', 'supplier', 'party', 'ledger_name', 'vendor', 'account_name'],
  vendorGstin: ['gstin', 'gst_no', 'gst_number', 'party_gstin', 'supplier_gstin', 'vendor_gstin', 'gstin_uin'],
  date: ['invoice_date', 'bill_date', 'date', 'voucher_date', 'posting_date', 'trans_date'],
  taxableAmount: ['taxable_value', 'taxable_amount', 'assessable_val', 'subtotal', 'net_amount'],
  cgst: ['cgst', 'cgst_amount', 'cgst_amt', 'central_tax', 'central_gst'],
  sgst: ['sgst', 'sgst_amount', 'sgst_amt', 'state_tax', 'state_gst', 'utgst'],
  igst: ['igst', 'igst_amount', 'igst_amt', 'integrated_tax', 'integrated_gst'],
  tax: ['total_gst', 'gst_amount', 'total_tax', 'tax_amount', 'gst', 'tax'],
  amount: ['total_amount', 'invoice_value', 'total_value', 'gross_amount', 'amount', 'total', 'bill_amount', 'debit'],
  description: ['narration', 'particulars', 'item_description', 'description', 'notes'],
  accountCode: ['hsn', 'hsn_sac', 'account_head', 'gl_code', 'category'],
};

function normalizeHeader(header: string): string {
  return String(header || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]/g, '_')
    .replace(/^_+|_+$/g, '');
}

function findBestColumnMatch(headers: string[], patterns: string[]): string | undefined {
  const normalized = headers.map(h => ({ original: h, norm: normalizeHeader(h) }));

  for (const pattern of patterns) {
    const match = normalized.find(h => h.norm === pattern);
    if (match) return match.original;
  }

  for (const pattern of patterns) {
    const match = normalized.find(h => h.norm.includes(pattern));
    if (match) return match.original;
  }

  return undefined;
}

function parseNumber(val: any): number {
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  if (typeof val === 'string') {
    const clean = val.replace(/[^0-9.-]/g, '');
    const num = parseFloat(clean);
    return isNaN(num) ? 0 : num;
  }
  return 0;
}

/**
 * Read and parse an Excel or CSV file
 */
export async function parseExcelLedger(file: File): Promise<ParseLedgerResult> {
  const arrayBuffer = await file.arrayBuffer();
  const workbook = XLSX.read(arrayBuffer, { type: 'array', cellDates: true });

  const firstSheetName = workbook.SheetNames[0];
  if (!firstSheetName) {
    throw new Error('Workbook contains no sheets.');
  }

  const worksheet = workbook.Sheets[firstSheetName];
  const rawRows: Record<string, any>[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

  if (rawRows.length === 0) {
    throw new Error('The uploaded ledger sheet is empty.');
  }

  const headers = Object.keys(rawRows[0]);

  const detectedInvoiceCol = findBestColumnMatch(headers, HEADER_PATTERNS.invoiceNumber) || headers[0];
  const detectedVendorCol = findBestColumnMatch(headers, HEADER_PATTERNS.vendorName) || headers[1] || headers[0];
  const detectedGstinCol = findBestColumnMatch(headers, HEADER_PATTERNS.vendorGstin);
  const detectedDateCol = findBestColumnMatch(headers, HEADER_PATTERNS.date) || headers[2] || headers[0];
  const detectedTaxableCol = findBestColumnMatch(headers, HEADER_PATTERNS.taxableAmount);
  const detectedCgstCol = findBestColumnMatch(headers, HEADER_PATTERNS.cgst);
  const detectedSgstCol = findBestColumnMatch(headers, HEADER_PATTERNS.sgst);
  const detectedIgstCol = findBestColumnMatch(headers, HEADER_PATTERNS.igst);
  const detectedTaxCol = findBestColumnMatch(headers, HEADER_PATTERNS.tax);
  const detectedAmountCol = findBestColumnMatch(headers, HEADER_PATTERNS.amount) || headers[headers.length - 1];
  const detectedDescCol = findBestColumnMatch(headers, HEADER_PATTERNS.description);
  const detectedAccountCol = findBestColumnMatch(headers, HEADER_PATTERNS.accountCode);

  const records: LedgerRecord[] = rawRows.map((row, index) => {
    const totalAmount = Math.abs(parseNumber(row[detectedAmountCol]));
    const cgstVal = detectedCgstCol ? Math.abs(parseNumber(row[detectedCgstCol])) : 0;
    const sgstVal = detectedSgstCol ? Math.abs(parseNumber(row[detectedSgstCol])) : 0;
    const igstVal = detectedIgstCol ? Math.abs(parseNumber(row[detectedIgstCol])) : 0;
    const rawTaxVal = detectedTaxCol ? Math.abs(parseNumber(row[detectedTaxCol])) : 0;
    const totalTaxVal = (cgstVal + sgstVal + igstVal) > 0 ? (cgstVal + sgstVal + igstVal) : rawTaxVal;
    const taxableVal = detectedTaxableCol ? Math.abs(parseNumber(row[detectedTaxableCol])) : (totalAmount - totalTaxVal);

    // Format date string
    let dateStr = '';
    const rawDate = row[detectedDateCol];
    if (rawDate instanceof Date && !isNaN(rawDate.getTime())) {
      dateStr = rawDate.toISOString().slice(0, 10);
    } else if (typeof rawDate === 'string') {
      dateStr = rawDate.trim();
    } else if (typeof rawDate === 'number') {
      const parsedDate = new Date(Math.round((rawDate - 25569) * 86400 * 1000));
      if (!isNaN(parsedDate.getTime())) {
        dateStr = parsedDate.toISOString().slice(0, 10);
      }
    }

    return {
      id: `ledger-row-${index + 1}`,
      rowIndex: index + 2,
      invoiceNumber: String(row[detectedInvoiceCol] || '').trim(),
      vendorName: String(row[detectedVendorCol] || 'Unknown Party').trim(),
      vendorGstin: detectedGstinCol && row[detectedGstinCol] ? String(row[detectedGstinCol]).trim().toUpperCase() : undefined,
      date: dateStr || 'N/A',
      taxableAmount: taxableVal,
      cgst: cgstVal,
      sgst: sgstVal,
      igst: igstVal,
      tax: totalTaxVal,
      amount: totalAmount,
      currency: 'INR',
      description: detectedDescCol ? String(row[detectedDescCol] || '') : undefined,
      accountCode: detectedAccountCol ? String(row[detectedAccountCol] || '') : undefined,
      rawRow: row,
    };
  });

  return {
    records,
    detectedColumns: {
      invoiceNumber: detectedInvoiceCol,
      vendorName: detectedVendorCol,
      vendorGstin: detectedGstinCol,
      date: detectedDateCol,
      taxableAmount: detectedTaxableCol,
      cgst: detectedCgstCol,
      sgst: detectedSgstCol,
      igst: detectedIgstCol,
      tax: detectedTaxCol,
      amount: detectedAmountCol,
      description: detectedDescCol,
      accountCode: detectedAccountCol,
    },
    totalRows: records.length,
  };
}

/**
 * Generate a ready-to-use Sample Indian GST Purchase Ledger Excel template (.xlsx)
 */
export function generateSampleLedgerFile(): Blob {
  const sampleData = [
    {
      'Voucher / Invoice #': 'INV/2026/089',
      'Supplier / Party Name': 'Tata Consultancy Services Ltd',
      'Supplier GSTIN': '27AAACT2879P1ZU',
      'Date': '2026-10-12',
      'Taxable Value (₹)': 100000.00,
      'CGST (9%) (₹)': 9000.00,
      'SGST (9%) (₹)': 9000.00,
      'IGST (₹)': 0.00,
      'Total GST (₹)': 18000.00,
      'Total Bill Amount (₹)': 118000.00,
      'HSN/SAC Code': '998313 (IT Services)',
      'Narration': 'Managed cloud & infra support services (Maharashtra Intra-State)',
    },
    {
      'Voucher / Invoice #': 'BLR-GST-4412',
      'Supplier / Party Name': 'Infosys BPM Technologies',
      'Supplier GSTIN': '29AAACI4744K1ZF',
      'Date': '2026-10-14',
      'Taxable Value (₹)': 150000.00,
      'CGST (9%) (₹)': 0.00,
      'SGST (9%) (₹)': 0.00,
      'IGST (18%) (₹)': 23400.00, // Discrepancy! Invoice IGST is ₹27,000 (18% on ₹1,50,000)
      'Total GST (₹)': 23400.00,
      'Total Bill Amount (₹)': 173400.00, // Discrepancy! Invoice is ₹1,77,000.00
      'HSN/SAC Code': '998314',
      'Narration': 'Karnataka Inter-State consulting (Amount & IGST discrepancy in ledger)',
    },
    {
      'Voucher / Invoice #': 'RD-MUM-99120',
      'Supplier / Party Name': 'Reliance Digital Retail Ltd',
      'Supplier GSTIN': '27AABCR0415A1Z1',
      'Date': '2026-10-16',
      'Taxable Value (₹)': 45000.00,
      'CGST (9%) (₹)': 0.00, // Discrepancy! Ledger booked zero tax, invoice has 9%+9% CGST+SGST ₹8,100
      'SGST (9%) (₹)': 0.00,
      'IGST (₹)': 0.00,
      'Total GST (₹)': 0.00,
      'Total Bill Amount (₹)': 45000.00, // Discrepancy! Invoice is ₹53,100.00
      'HSN/SAC Code': '847130',
      'Narration': 'Office laptop workstations (Taxes missed during entry)',
    },
    {
      'Voucher / Invoice #': 'ZOM-CORP-3108',
      'Supplier / Party Name': 'Zomato Media Pvt Ltd',
      'Supplier GSTIN': '06AAACZ1708E1ZZ',
      'Date': '2026-10-18',
      'Taxable Value (₹)': 25000.00,
      'CGST (9%) (₹)': 0.00,
      'SGST (9%) (₹)': 0.00,
      'IGST (5%) (₹)': 1250.00,
      'Total GST (₹)': 1250.00,
      'Total Bill Amount (₹)': 26250.00,
      'HSN/SAC Code': '996331',
      'Narration': 'Corporate team meals catering (Matches invoice)',
    },
    {
      'Voucher / Invoice #': 'AIR-DEL-7704',
      'Supplier / Party Name': 'Bharti Airtel Telecom Ltd',
      'Supplier GSTIN': '07AAACB2894G1ZV',
      'Date': '2026-10-19',
      'Taxable Value (₹)': 32000.00,
      'CGST (9%) (₹)': 0.00,
      'SGST (9%) (₹)': 0.00,
      'IGST (18%) (₹)': 5760.00,
      'Total GST (₹)': 5760.00,
      'Total Bill Amount (₹)': 37760.00,
      'HSN/SAC Code': '998411',
      'Narration': 'Enterprise leased line bandwidth (No invoice uploaded yet)',
    },
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData);
  worksheet['!cols'] = [
    { wch: 22 }, // Inv #
    { wch: 30 }, // Supplier
    { wch: 18 }, // GSTIN
    { wch: 14 }, // Date
    { wch: 18 }, // Taxable
    { wch: 15 }, // CGST
    { wch: 15 }, // SGST
    { wch: 15 }, // IGST
    { wch: 16 }, // Total GST
    { wch: 20 }, // Total Bill
    { wch: 24 }, // HSN
    { wch: 38 }, // Narration
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Purchase Ledger');

  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  return new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

/**
 * Generate comprehensive multi-sheet Indian GST Excel export report:
 * • Extracted Invoice Data (Taxable Value, CGST, SGST, IGST, Total Amount)
 * • Status: Matched / Mismatched / Not in Ledger
 */
export function exportReconciliationReport(
  items: ReconciliationItem[],
  summary: ReconciliationSummary,
  fileNamePrefix: string = 'GST_Reconciliation_Report'
): void {
  const workbook = XLSX.utils.book_new();

  // 1. Executive Summary Sheet
  const summarySheetData = [
    ['GST INVOICE RECONCILIATION AUDIT REPORT (INDIA)', ''],
    ['Generated On:', new Date().toLocaleString('en-IN')],
    ['Currency:', 'INR (₹)'],
    ['Tax Structure:', 'CGST, SGST, IGST (Indian GST Act)'],
    ['', ''],
    ['RECONCILIATION SUMMARY', 'VALUE / COUNT'],
    ['Total Invoices Scanned', summary.totalInvoices],
    ['Total Ledger Records', summary.totalLedgerRecords],
    ['Reconciliation Match Rate', `${summary.matchRatePercent.toFixed(1)}%`],
    ['Total Invoiced Volume (₹)', summary.totalInvoiceAmount],
    ['Total Ledger Volume (₹)', summary.totalLedgerAmount],
    ['Total CGST Claimable (₹)', summary.totalCgst],
    ['Total SGST Claimable (₹)', summary.totalSgst],
    ['Total IGST Claimable (₹)', summary.totalIgst],
    ['', ''],
    ['STATUS BREAKDOWN', 'COUNT', 'AMOUNT (₹)'],
    ['Matched (Input Tax Credit Cleared)', summary.matchedCount, summary.totalMatchedAmount],
    ['Mismatches (Tax / Value Discrepancies)', summary.mismatchedCount, summary.totalDiscrepancyAmount],
    ['Not in Ledger (Unrecorded Invoices)', summary.notInLedgerCount, items.filter(i => i.status === 'NOT_IN_LEDGER').reduce((acc, i) => acc + (i.invoice?.totalAmount || 0), 0)],
    ['Missing Invoices (In Ledger Only)', summary.notInInvoicesCount, items.filter(i => i.status === 'NOT_IN_INVOICES').reduce((acc, i) => acc + (i.ledger?.amount || 0), 0)],
  ];
  const summaryWs = XLSX.utils.aoa_to_sheet(summarySheetData);
  summaryWs['!cols'] = [{ wch: 38 }, { wch: 22 }, { wch: 22 }];
  XLSX.utils.book_append_sheet(workbook, summaryWs, 'Summary');

  // 2. Comprehensive Reconciliation Master Sheet
  const masterHeaders = [
    'Status',
    'Invoice #',
    'Supplier / Vendor',
    'Vendor GSTIN',
    'Invoice Date',
    'Taxable Value (₹)',
    'Invoice CGST (₹)',
    'Invoice SGST (₹)',
    'Invoice IGST (₹)',
    'Total GST (₹)',
    'Invoice Total (₹)',
    'Ledger Ref #',
    'Ledger Total (₹)',
    'Ledger CGST (₹)',
    'Ledger SGST (₹)',
    'Ledger IGST (₹)',
    'Amount Diff (₹)',
    'CGST Diff (₹)',
    'SGST Diff (₹)',
    'IGST Diff (₹)',
    'Discrepancy Details / CA Remarks',
    'Match Confidence',
  ];

  const formatStatus = (s: string) => {
    switch (s) {
      case 'MATCHED': return 'Matched';
      case 'MISMATCHED': return 'Mismatched';
      case 'NOT_IN_LEDGER': return 'Not in Ledger';
      case 'NOT_IN_INVOICES': return 'Missing Invoice';
      default: return s;
    }
  };

  const masterRows = items.map(item => {
    const inv = item.invoice;
    const led = item.ledger;
    const discrepancyNotes = item.discrepancies.map(d => d.message).join('; ') || item.resolutionNote || 'Verified';

    return [
      formatStatus(item.status),
      inv?.invoiceNumber || (led ? `Ledger: ${led.invoiceNumber}` : 'N/A'),
      inv?.vendorName || led?.vendorName || 'N/A',
      inv?.vendorGstin || led?.vendorGstin || 'N/A',
      inv?.invoiceDate || led?.date || 'N/A',
      inv ? inv.subtotal : 'N/A',
      inv ? inv.cgst : 'N/A',
      inv ? inv.sgst : 'N/A',
      inv ? inv.igst : 'N/A',
      inv ? inv.taxAmount : 'N/A',
      inv ? inv.totalAmount : 'N/A',
      led ? led.invoiceNumber : 'N/A',
      led ? led.amount : 'N/A',
      led ? led.cgst : 'N/A',
      led ? led.sgst : 'N/A',
      led ? led.igst : 'N/A',
      item.amountVariance !== 0 ? item.amountVariance : 0,
      item.cgstVariance !== 0 ? item.cgstVariance : 0,
      item.sgstVariance !== 0 ? item.sgstVariance : 0,
      item.igstVariance !== 0 ? item.igstVariance : 0,
      discrepancyNotes,
      `${item.matchScore}%`,
    ];
  });

  const masterWs = XLSX.utils.aoa_to_sheet([masterHeaders, ...masterRows]);
  masterWs['!cols'] = [
    { wch: 16 }, // Status
    { wch: 18 }, // Invoice #
    { wch: 30 }, // Vendor
    { wch: 18 }, // GSTIN
    { wch: 13 }, // Date
    { wch: 16 }, // Taxable
    { wch: 15 }, // CGST
    { wch: 15 }, // SGST
    { wch: 15 }, // IGST
    { wch: 15 }, // Total GST
    { wch: 17 }, // Total Amount
    { wch: 18 }, // Ledger Ref
    { wch: 17 }, // Ledger Total
    { wch: 15 }, // Ledger CGST
    { wch: 15 }, // Ledger SGST
    { wch: 15 }, // Ledger IGST
    { wch: 15 }, // Amount Diff
    { wch: 14 }, // CGST Diff
    { wch: 14 }, // SGST Diff
    { wch: 14 }, // IGST Diff
    { wch: 45 }, // Notes
    { wch: 14 }, // Score
  ];
  XLSX.utils.book_append_sheet(workbook, masterWs, 'All Reconciliations');

  // 3. Matched Sheet
  const matchedRows = masterRows.filter(row => row[0] === 'Matched');
  if (matchedRows.length > 0) {
    const matchedWs = XLSX.utils.aoa_to_sheet([masterHeaders, ...matchedRows]);
    matchedWs['!cols'] = masterWs['!cols'];
    XLSX.utils.book_append_sheet(workbook, matchedWs, 'Matched');
  }

  // 4. Mismatched Sheet
  const mismatchedRows = masterRows.filter(row => row[0] === 'Mismatched');
  if (mismatchedRows.length > 0) {
    const mismatchedWs = XLSX.utils.aoa_to_sheet([masterHeaders, ...mismatchedRows]);
    mismatchedWs['!cols'] = masterWs['!cols'];
    XLSX.utils.book_append_sheet(workbook, mismatchedWs, 'Mismatches');
  }

  // 5. Not in Ledger Sheet
  const notInLedgerRows = masterRows.filter(row => row[0] === 'Not in Ledger');
  if (notInLedgerRows.length > 0) {
    const notInLedgerWs = XLSX.utils.aoa_to_sheet([masterHeaders, ...notInLedgerRows]);
    notInLedgerWs['!cols'] = masterWs['!cols'];
    XLSX.utils.book_append_sheet(workbook, notInLedgerWs, 'Not in Ledger');
  }

  // Download
  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `${fileNamePrefix}_${dateStr}.xlsx`);
}
