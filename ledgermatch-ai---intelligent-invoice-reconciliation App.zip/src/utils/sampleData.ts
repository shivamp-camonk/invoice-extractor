import { ExtractedInvoice, LedgerRecord } from '../types/reconciliation';
import { formatINR } from './matchingEngine';

/**
 * Helper to render an Indian Tax Invoice voucher as an SVG data URL
 */
function createIndianInvoiceSvgDataUrl(
  vendor: string,
  gstin: string,
  invoiceNum: string,
  date: string,
  state: string,
  taxable: number,
  cgst: number,
  sgst: number,
  igst: number,
  total: number,
  items: Array<{ desc: string; hsn: string; qty: number; rate: number; amount: number }>
): string {
  const isInterState = igst > 0;
  const itemsSvgRows = items
    .map(
      (it, idx) => `
    <tr style="border-bottom: 1px solid #e2e8f0;">
      <td style="padding: 8px 12px; font-size: 12px; color: #1e293b;">${it.desc}</td>
      <td style="padding: 8px 12px; font-size: 12px; text-align: center; color: #475569; font-family: monospace;">${it.hsn}</td>
      <td style="padding: 8px 12px; font-size: 12px; text-align: center; color: #475569;">${it.qty}</td>
      <td style="padding: 8px 12px; font-size: 12px; text-align: right; color: #475569;">₹${it.rate.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
      <td style="padding: 8px 12px; font-size: 12px; text-align: right; font-weight: 600; color: #0f172a;">₹${it.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
    </tr>
  `
    )
    .join('');

  const taxRows = isInterState
    ? `
      <div style="display: flex; justify-content: space-between; padding: 5px 0; font-size: 12px; color: #475569;">
        <span>Integrated GST (IGST @ 18%):</span>
        <span style="font-weight: 600;">₹${igst.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
      </div>
    `
    : `
      <div style="display: flex; justify-content: space-between; padding: 5px 0; font-size: 12px; color: #475569;">
        <span>Central GST (CGST @ 9%):</span>
        <span style="font-weight: 600;">₹${cgst.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
      </div>
      <div style="display: flex; justify-content: space-between; padding: 5px 0; font-size: 12px; color: #475569;">
        <span>State GST (SGST @ 9%):</span>
        <span style="font-weight: 600;">₹${sgst.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
      </div>
    `;

  const html = `
    <svg xmlns="http://www.w3.org/2000/svg" width="700" height="860" viewBox="0 0 700 860">
      <foreignObject width="100%" height="100%">
        <div xmlns="http://www.w3.org/1999/xhtml" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #ffffff; width: 700px; height: 860px; box-sizing: border-box; padding: 36px; color: #0f172a;">
          
          <!-- Top Header -->
          <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 24px;">
            <div>
              <h1 style="margin: 0 0 4px 0; font-size: 20px; font-weight: 800; color: #0f172a;">${vendor}</h1>
              <p style="margin: 0; font-size: 11px; font-weight: 700; color: #4338ca; font-family: monospace;">GSTIN: ${gstin}</p>
              <p style="margin: 2px 0 0 0; font-size: 11px; color: #64748b;">State: ${state} · Registered Taxable Person</p>
            </div>
            <div style="text-align: right;">
              <span style="display: inline-block; background: #1e293b; color: #ffffff; font-size: 10px; font-weight: 700; text-transform: uppercase; padding: 3px 8px; border-radius: 4px; letter-spacing: 0.5px;">TAX INVOICE (GST)</span>
              <p style="margin: 8px 0 0 0; font-size: 13px; font-weight: 700; color: #0f172a;">Invoice #: ${invoiceNum}</p>
              <p style="margin: 2px 0 0 0; font-size: 11px; color: #64748b;">Date: ${date}</p>
            </div>
          </div>

          <!-- Billed to -->
          <div style="display: flex; justify-content: space-between; margin-bottom: 24px; font-size: 11px; background: #f8fafc; padding: 12px; border-radius: 6px; border: 1px solid #e2e8f0;">
            <div>
              <span style="text-transform: uppercase; font-weight: 700; color: #64748b; font-size: 10px;">Billed To / Buyer:</span>
              <p style="margin: 3px 0 0 0; font-weight: 700; font-size: 12px; color: #0f172a;">Acme Technologies India Pvt Ltd</p>
              <p style="margin: 1px 0 0 0; color: #475569; font-family: monospace; font-weight: 600;">GSTIN: 27AABCA9918K1ZV</p>
              <p style="margin: 1px 0 0 0; color: #475569;">Bandra-Kurla Complex, Mumbai, Maharashtra (27)</p>
            </div>
            <div style="text-align: right;">
              <span style="text-transform: uppercase; font-weight: 700; color: #64748b; font-size: 10px;">Tax Classification:</span>
              <p style="margin: 3px 0 0 0; font-weight: 700; color: #0f172a;">${isInterState ? 'Inter-State (IGST Applicable)' : 'Intra-State (CGST + SGST Applicable)'}</p>
              <p style="margin: 1px 0 0 0; color: #475569;">Place of Supply: ${state}</p>
              <p style="margin: 1px 0 0 0; color: #475569;">Currency: Indian Rupee (INR ₹)</p>
            </div>
          </div>

          <!-- Items Table -->
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <thead>
              <tr style="background: #f1f5f9; border-top: 1px solid #cbd5e1; border-bottom: 1px solid #cbd5e1;">
                <th style="padding: 8px 12px; font-size: 11px; text-transform: uppercase; text-align: left; color: #475569;">Particulars / Description</th>
                <th style="padding: 8px 12px; font-size: 11px; text-transform: uppercase; text-align: center; color: #475569; width: 80px;">HSN/SAC</th>
                <th style="padding: 8px 12px; font-size: 11px; text-transform: uppercase; text-align: center; color: #475569; width: 50px;">Qty</th>
                <th style="padding: 8px 12px; font-size: 11px; text-transform: uppercase; text-align: right; color: #475569; width: 110px;">Rate (₹)</th>
                <th style="padding: 8px 12px; font-size: 11px; text-transform: uppercase; text-align: right; color: #475569; width: 120px;">Amount (₹)</th>
              </tr>
            </thead>
            <tbody>
              ${itemsSvgRows}
            </tbody>
          </table>

          <!-- Tax Breakdown -->
          <div style="display: flex; justify-content: flex-end; margin-top: 12px;">
            <div style="width: 320px; background: #fafafa; border: 1px solid #e2e8f0; padding: 14px; border-radius: 6px;">
              <div style="display: flex; justify-content: space-between; padding: 5px 0; font-size: 12px; color: #475569;">
                <span>Taxable Value:</span>
                <span style="font-weight: 600;">₹${taxable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
              ${taxRows}
              <div style="display: flex; justify-content: space-between; padding: 10px 0 4px 0; border-top: 2px solid #0f172a; margin-top: 6px; font-size: 15px; font-weight: 800; color: #0f172a;">
                <span>Total Invoice Value:</span>
                <span>₹${total.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
            </div>
          </div>

          <!-- Bottom Footer -->
          <div style="margin-top: 40px; padding-top: 14px; border-top: 1px dashed #cbd5e1; font-size: 10px; color: #64748b; display: flex; justify-content: space-between; align-items: flex-end;">
            <div>
              <p style="margin: 0; font-weight: 600;">Declaration:</p>
              <p style="margin: 2px 0 0 0;">We declare that this invoice shows the actual price of the goods or services described and that all particulars are true and correct.</p>
            </div>
            <div style="text-align: right; min-width: 160px;">
              <p style="margin: 0; font-weight: 700; color: #0f172a;">For ${vendor}</p>
              <p style="margin: 28px 0 0 0; border-top: 1px solid #94a3b8; font-size: 9px; padding-top: 2px;">Authorized Signatory</p>
            </div>
          </div>

        </div>
      </foreignObject>
    </svg>
  `;

  return `data:image/svg+xml;utf8,${encodeURIComponent(html)}`;
}

export const SAMPLE_INVOICES: ExtractedInvoice[] = [
  {
    id: 'sample-inv-1',
    fileName: 'TCS_INV_2026_089.pdf',
    fileSize: 148200,
    fileType: 'application/pdf',
    uploadedAt: '2026-10-21 10:15',
    status: 'extracted',
    vendorName: 'Tata Consultancy Services Ltd',
    vendorGstin: '27AAACT2879P1ZU',
    invoiceNumber: 'INV/2026/089',
    invoiceDate: '2026-10-12',
    dueDate: '2026-11-12',
    placeOfSupply: 'Maharashtra (27)',
    subtotal: 100000.00,
    cgst: 9000.00,
    sgst: 9000.00,
    igst: 0.00,
    taxAmount: 18000.00,
    totalAmount: 118000.00, // Matches Ledger!
    currency: 'INR',
    confidenceScore: 0.99,
    notes: 'PO-MUM-8921 verified · Intra-State (CGST 9% + SGST 9%)',
    lineItems: [
      {
        description: 'Managed Cloud Architecture Support (Monthly)',
        hsnSac: '998313',
        quantity: 1,
        unitPrice: 100000.00,
        amount: 100000.00,
        cgst: 9000.00,
        sgst: 9000.00,
      },
    ],
    fileDataUrl: createIndianInvoiceSvgDataUrl(
      'Tata Consultancy Services Ltd',
      '27AAACT2879P1ZU',
      'INV/2026/089',
      '2026-10-12',
      'Maharashtra (27)',
      100000.00,
      9000.00,
      9000.00,
      0.00,
      118000.00,
      [{ desc: 'Managed Cloud Architecture Support', hsn: '998313', qty: 1, rate: 100000.00, amount: 100000.00 }]
    ),
  },
  {
    id: 'sample-inv-2',
    fileName: 'Infosys_BLR_GST_4412.pdf',
    fileSize: 212400,
    fileType: 'application/pdf',
    uploadedAt: '2026-10-21 10:16',
    status: 'extracted',
    vendorName: 'Infosys BPM Technologies',
    vendorGstin: '29AAACI4744K1ZF',
    invoiceNumber: 'BLR-GST-4412',
    invoiceDate: '2026-10-14',
    dueDate: '2026-11-14',
    placeOfSupply: 'Karnataka to Maharashtra (Inter-State)',
    subtotal: 150000.00,
    cgst: 0.00,
    sgst: 0.00,
    igst: 27000.00, // 18% IGST on ₹1,50,000 -> Ledger only has ₹23,400!
    taxAmount: 27000.00,
    totalAmount: 177000.00, // Ledger has ₹1,73,400 -> Discrepancy: ₹3,600!
    currency: 'INR',
    confidenceScore: 0.98,
    notes: 'Inter-State IT Consulting (IGST 18% applied)',
    lineItems: [
      {
        description: 'Enterprise ERP Implementation Support',
        hsnSac: '998314',
        quantity: 1,
        unitPrice: 150000.00,
        amount: 150000.00,
        igst: 27000.00,
      },
    ],
    fileDataUrl: createIndianInvoiceSvgDataUrl(
      'Infosys BPM Technologies',
      '29AAACI4744K1ZF',
      'BLR-GST-4412',
      '2026-10-14',
      'Karnataka (29)',
      150000.00,
      0.00,
      0.00,
      27000.00,
      177000.00,
      [{ desc: 'Enterprise ERP Implementation Support', hsn: '998314', qty: 1, rate: 150000.00, amount: 150000.00 }]
    ),
  },
  {
    id: 'sample-inv-3',
    fileName: 'Reliance_Digital_RD_MUM_99120.png',
    fileSize: 320100,
    fileType: 'image/png',
    uploadedAt: '2026-10-21 10:17',
    status: 'extracted',
    vendorName: 'Reliance Digital Retail Ltd',
    vendorGstin: '27AABCR0415A1Z1',
    invoiceNumber: 'RD-MUM-99120',
    invoiceDate: '2026-10-16',
    dueDate: '2026-10-30',
    placeOfSupply: 'Maharashtra (27)',
    subtotal: 45000.00,
    cgst: 4050.00, // Ledger has ₹0 tax recorded!
    sgst: 4050.00,
    igst: 0.00,
    taxAmount: 8100.00,
    totalAmount: 53100.00, // Ledger booked ₹45,000 without GST!
    currency: 'INR',
    confidenceScore: 0.97,
    notes: 'Hardware purchase for development team (CGST 9% + SGST 9%)',
    lineItems: [
      {
        description: 'Dell UltraSharp 32-inch 4K Developer Displays',
        hsnSac: '847130',
        quantity: 1,
        unitPrice: 45000.00,
        amount: 45000.00,
        cgst: 4050.00,
        sgst: 4050.00,
      },
    ],
    fileDataUrl: createIndianInvoiceSvgDataUrl(
      'Reliance Digital Retail Ltd',
      '27AABCR0415A1Z1',
      'RD-MUM-99120',
      '2026-10-16',
      'Maharashtra (27)',
      45000.00,
      4050.00,
      4050.00,
      0.00,
      53100.00,
      [{ desc: 'Dell UltraSharp 32-inch 4K Developer Display', hsn: '847130', qty: 1, rate: 45000.00, amount: 45000.00 }]
    ),
  },
  {
    id: 'sample-inv-4',
    fileName: 'Swiggy_SWIG_CORP_810.pdf',
    fileSize: 189000,
    fileType: 'application/pdf',
    uploadedAt: '2026-10-21 10:18',
    status: 'extracted',
    vendorName: 'Swiggy Bundl Technologies Pvt Ltd',
    vendorGstin: '29AAGCB3918Q1ZV',
    invoiceNumber: 'SWIG-CORP-810',
    invoiceDate: '2026-10-17',
    dueDate: '2026-11-01',
    placeOfSupply: 'Karnataka to Maharashtra (27)',
    subtotal: 18500.00,
    cgst: 0.00,
    sgst: 0.00,
    igst: 925.00, // 5% IGST on food delivery service
    taxAmount: 925.00,
    totalAmount: 19425.00, // Not in ledger at all!
    currency: 'INR',
    confidenceScore: 0.99,
    notes: 'Q3 All-Hands Engineering Lunch Catering (Unrecorded in Tally)',
    lineItems: [
      {
        description: 'Corporate Meal Vouchers & Event Catering',
        hsnSac: '996331',
        quantity: 1,
        unitPrice: 18500.00,
        amount: 18500.00,
        igst: 925.00,
      },
    ],
    fileDataUrl: createIndianInvoiceSvgDataUrl(
      'Swiggy Bundl Technologies Pvt Ltd',
      '29AAGCB3918Q1ZV',
      'SWIG-CORP-810',
      '2026-10-17',
      'Karnataka (29)',
      18500.00,
      0.00,
      0.00,
      925.00,
      19425.00,
      [{ desc: 'Corporate Meal Vouchers & Event Catering', hsn: '996331', qty: 1, rate: 18500.00, amount: 18500.00 }]
    ),
  },
  {
    id: 'sample-inv-5',
    fileName: 'Zomato_ZOM_CORP_3108.pdf',
    fileSize: 175400,
    fileType: 'application/pdf',
    uploadedAt: '2026-10-21 10:19',
    status: 'extracted',
    vendorName: 'Zomato Media Pvt Ltd',
    vendorGstin: '06AAACZ1708E1ZZ',
    invoiceNumber: 'ZOM-CORP-3108',
    invoiceDate: '2026-10-18',
    dueDate: '2026-11-02',
    placeOfSupply: 'Haryana to Maharashtra (27)',
    subtotal: 25000.00,
    cgst: 0.00,
    sgst: 0.00,
    igst: 1250.00,
    taxAmount: 1250.00,
    totalAmount: 26250.00, // Matches Ledger!
    currency: 'INR',
    confidenceScore: 0.98,
    notes: 'Corporate catering billing · Verified input tax credit',
    lineItems: [
      {
        description: 'Corporate Dining Solutions Batch #4',
        hsnSac: '996331',
        quantity: 1,
        unitPrice: 25000.00,
        amount: 25000.00,
        igst: 1250.00,
      },
    ],
    fileDataUrl: createIndianInvoiceSvgDataUrl(
      'Zomato Media Pvt Ltd',
      '06AAACZ1708E1ZZ',
      'ZOM-CORP-3108',
      '2026-10-18',
      'Haryana (06)',
      25000.00,
      0.00,
      0.00,
      1250.00,
      26250.00,
      [{ desc: 'Corporate Dining Solutions Batch #4', hsn: '996331', qty: 1, rate: 25000.00, amount: 25000.00 }]
    ),
  },
];

export const SAMPLE_LEDGER_RECORDS: LedgerRecord[] = [
  {
    id: 'sample-led-1',
    rowIndex: 2,
    invoiceNumber: 'INV/2026/089',
    vendorName: 'Tata Consultancy Services Ltd',
    vendorGstin: '27AAACT2879P1ZU',
    date: '2026-10-12',
    taxableAmount: 100000.00,
    cgst: 9000.00,
    sgst: 9000.00,
    igst: 0.00,
    tax: 18000.00,
    amount: 118000.00, // Matched!
    currency: 'INR',
    accountCode: 'GL-6100 (Cloud Hosting & Infra)',
    description: 'Managed cloud services (Intra-state Maharashtra)',
  },
  {
    id: 'sample-led-2',
    rowIndex: 3,
    invoiceNumber: 'BLR-GST-4412',
    vendorName: 'Infosys BPM Technologies',
    vendorGstin: '29AAACI4744K1ZF',
    date: '2026-10-14',
    taxableAmount: 150000.00,
    cgst: 0.00,
    sgst: 0.00,
    igst: 23400.00, // Invoice IGST is ₹27,000 -> Discrepancy!
    tax: 23400.00,
    amount: 173400.00, // Invoice is ₹1,77,000 -> ₹3,600 Discrepancy!
    currency: 'INR',
    accountCode: 'GL-5200 (ERP Consulting)',
    description: 'Inter-state consulting (Tax entered incorrectly as ₹23,400)',
  },
  {
    id: 'sample-led-3',
    rowIndex: 4,
    invoiceNumber: 'RD-MUM-99120',
    vendorName: 'Reliance Digital Retail Ltd',
    vendorGstin: '27AABCR0415A1Z1',
    date: '2026-10-16',
    taxableAmount: 45000.00,
    cgst: 0.00, // Invoice has ₹4,050 CGST + ₹4,050 SGST -> Discrepancy!
    sgst: 0.00,
    igst: 0.00,
    tax: 0.00,
    amount: 45000.00, // Invoice is ₹53,100 -> ₹8,100 Discrepancy!
    currency: 'INR',
    accountCode: 'GL-1400 (Computer Hardware)',
    description: 'Developer displays (Tax was omitted during voucher creation)',
  },
  {
    id: 'sample-led-4',
    rowIndex: 5,
    invoiceNumber: 'ZOM-CORP-3108',
    vendorName: 'Zomato Media Pvt Ltd',
    vendorGstin: '06AAACZ1708E1ZZ',
    date: '2026-10-18',
    taxableAmount: 25000.00,
    cgst: 0.00,
    sgst: 0.00,
    igst: 1250.00,
    tax: 1250.00,
    amount: 26250.00, // Matched!
    currency: 'INR',
    accountCode: 'GL-6500 (Staff Welfare)',
    description: 'Corporate catering billing',
  },
  {
    id: 'sample-led-5',
    rowIndex: 6,
    invoiceNumber: 'AIR-DEL-7704',
    vendorName: 'Bharti Airtel Telecom Ltd',
    vendorGstin: '07AAACB2894G1ZV',
    date: '2026-10-19',
    taxableAmount: 32000.00,
    cgst: 0.00,
    sgst: 0.00,
    igst: 5760.00,
    tax: 5760.00,
    amount: 37760.00, // In ledger only!
    currency: 'INR',
    accountCode: 'GL-6300 (Telecommunications)',
    description: 'Dedicated fiber circuit (No invoice uploaded yet)',
  },
];
